package Wang;

import it.unisa.dia.gas.jpbc.Element;
import it.unisa.dia.gas.jpbc.Pairing;
import it.unisa.dia.gas.plaf.jpbc.pairing.PairingFactory;

import java.io.BufferedWriter;
import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.Locale;

/**
 * Benchmark for Wang et al., "Bidirectional Identity-Based Inner-Product
 * Functional Re-Encryption in Vaccine Data Sharing" (IEEE TCC, 2025).
 * Uses the paper's Setup, KeyGen, Enc and original Dec equations with the
 * project's JPBC symmetric Type-A parameters. Timing excludes file I/O.
 */
public final class WangIPFREBenchmark {
    private static final int[] DIMENSIONS = {10, 15, 20, 25};
    private static final int WARMUPS = 5, SAMPLES = 25;
    private static final String USER_ID = "RI-1";
    private final Pairing pairing;
    private final String pairingFile;

    private WangIPFREBenchmark(String pairingFile) {
        this.pairingFile=pairingFile;
        PairingFactory.getInstance().setUsePBCWhenPossible(true);
        this.pairing=PairingFactory.getPairing(pairingFile);
    }

    private static final class PublicParams {
        final Element g,h,g1;
        PublicParams(Element g,Element h,Element g1) {
            this.g=g; this.h=h; this.g1=g1;
        }
    }
    private static final class SetupResult {
        final PublicParams pp; final Element alpha;
        SetupResult(PublicParams pp,Element alpha) { this.pp=pp; this.alpha=alpha; }
    }
    private static final class PrivateKey {
        final Element id,rid; final Element[] y,hid;
        PrivateKey(Element id,Element rid,Element[] y,Element[] hid) {
            this.id=id; this.rid=rid; this.y=y; this.hid=hid;
        }
    }
    private static final class Ciphertext {
        final Element id,c1,c2; final Element[] cx;
        Ciphertext(Element id,Element c1,Element c2,Element[] cx) {
            this.id=id; this.c1=c1; this.c2=c2; this.cx=cx;
        }
    }

    private Element randomScalar() { return pairing.getZr().newRandomElement().getImmutable(); }
    private Element idScalar(String id) {
        byte[] b=id.getBytes(StandardCharsets.UTF_8);
        return pairing.getZr().newElementFromHash(b,0,b.length).getImmutable();
    }

    /** Setup: g1=g^alpha, msk=alpha, and publish g,h. */
    private SetupResult setup() {
        Element g=pairing.getG1().newRandomElement().getImmutable();
        Element h=pairing.getG1().newRandomElement().getImmutable();
        Element alpha=randomScalar(), id=idScalar(USER_ID);
        while (alpha.isEqual(id)) alpha=randomScalar();
        Element g1=g.powZn(alpha).getImmutable();
        return new SetupResult(new PublicParams(g,h,g1),alpha);
    }

    /** KeyGen: h_id[i]=(h*g^(-r_id))^(y_i/(alpha-id)). */
    private PrivateKey keyGen(SetupResult st,Element id,Element[] y) {
        Element den=st.alpha.duplicate().sub(id).getImmutable();
        if (den.isZero()) throw new IllegalArgumentException("alpha equals identity scalar");
        Element rid=randomScalar();
        Element b=st.pp.h.mul(st.pp.g.powZn(rid.duplicate().negate())).getImmutable();
        Element denInv=den.invert().getImmutable();
        Element[] hid=new Element[y.length];
        for (int i=0;i<y.length;i++) hid[i]=b.powZn(y[i].duplicate().mul(denInv)).getImmutable();
        return new PrivateKey(id,rid,y.clone(),hid);
    }

    /** Enc: C1=g1^s*g^(-s id), C2=e(g,g)^s, Cx[i]=e(g,h)^(-s)e(g,g)^x_i. */
    private Ciphertext encrypt(SetupResult st,Element id,Element[] x) {
        Element s=randomScalar();
        Element egg=pairing.pairing(st.pp.g,st.pp.g).getImmutable();
        Element egh=pairing.pairing(st.pp.g,st.pp.h).getImmutable();
        Element c1=st.pp.g1.powZn(s).mul(st.pp.g.powZn(s.duplicate().mul(id).negate())).getImmutable();
        Element c2=egg.powZn(s).getImmutable();
        Element blind=egh.powZn(s.duplicate().negate()).getImmutable();
        Element[] cx=new Element[x.length];
        for (int i=0;i<x.length;i++) cx[i]=blind.mul(egg.powZn(x[i])).getImmutable();
        return new Ciphertext(id,c1,c2,cx);
    }

    /** Dec outputs the GT encoding e(g,g)^<x,y>. */
    private Element decrypt(Ciphertext ct,PrivateKey sk) {
        if (!ct.id.isEqual(sk.id)) throw new IllegalArgumentException("identity mismatch");
        Element a1=pairing.getGT().newOneElement();
        Element hidProd=pairing.getG1().newOneElement();
        Element ySum=pairing.getZr().newZeroElement();
        for (int i=0;i<sk.y.length;i++) {
            a1.mul(ct.cx[i].powZn(sk.y[i]));
            hidProd.mul(sk.hid[i]);
            ySum.add(sk.y[i]);
        }
        Element a2=pairing.pairing(ct.c1,hidProd);
        Element a3=ct.c2.powZn(sk.rid.duplicate().mul(ySum));
        return a1.mul(a2).mul(a3).getImmutable();
    }

    private double medianMs(Runnable op) {
        for (int i=0;i<WARMUPS;i++) op.run();
        long[] ns=new long[SAMPLES];
        for (int i=0;i<SAMPLES;i++) { long t=System.nanoTime(); op.run(); ns[i]=System.nanoTime()-t; }
        Arrays.sort(ns);
        return ns[ns.length/2]/1_000_000.0;
    }

    private void run(String outputFile) throws Exception {
        Path csv=Paths.get(outputFile);
        if (csv.getParent()!=null) Files.createDirectories(csv.getParent());
        try (BufferedWriter out=Files.newBufferedWriter(csv,StandardCharsets.UTF_8)) {
            out.write("n,setup_ms,encryption_ms,keygen_ms,decryption_ms,inner_product,correct\n");
            for (int n:DIMENSIONS) {
                double setupMs=medianMs(this::setup);
                SetupResult st=setup(); Element id=idScalar(USER_ID);
                Element[] x=new Element[n],y=new Element[n]; long dot=0;
                for (int i=0;i<n;i++) {
                    int xv=1+i%5,yv=1+(i+2)%5;
                    x[i]=pairing.getZr().newElement(xv).getImmutable();
                    y[i]=pairing.getZr().newElement(yv).getImmutable(); dot+=(long)xv*yv;
                }
                Ciphertext ct=encrypt(st,id,x); PrivateKey sk=keyGen(st,id,y);
                double encMs=medianMs(()->encrypt(st,id,x));
                double keyMs=medianMs(()->keyGen(st,id,y));
                double decMs=medianMs(()->decrypt(ct,sk));
                Element got=decrypt(ct,sk);
                Element want=pairing.pairing(st.pp.g,st.pp.g)
                        .powZn(pairing.getZr().newElement(BigInteger.valueOf(dot)));
                boolean correct=got.isEqual(want);
                out.write(String.format(Locale.US,"%d,%.6f,%.6f,%.6f,%.6f,%d,%s%n",n,setupMs,encMs,keyMs,decMs,dot,correct));
                out.flush();
                System.out.printf(Locale.US,"n=%d Setup=%.6f ms Enc=%.6f ms KeyGen=%.6f ms Dec=%.6f ms dot=%d correct=%s%n",n,setupMs,encMs,keyMs,decMs,dot,correct);
            }
        }
        System.out.println("CSV="+csv.toAbsolutePath());
        System.out.printf("JPBC=%s, warmups=%d, samples=%d%n",pairingFile,WARMUPS,SAMPLES);
    }

    public static void main(String[] args) throws Exception {
        String params=args.length>0?args[0]:"storeFile/Ours_File/a.properties";
        String csv=args.length>1?args[1]:"wang-ipfre-benchmark.csv";
        new WangIPFREBenchmark(params).run(csv);
    }
}
