import it.unisa.dia.gas.jpbc.Element;
import it.unisa.dia.gas.jpbc.Pairing;
import it.unisa.dia.gas.plaf.jpbc.pairing.PairingFactory;

import java.security.NoSuchAlgorithmException;

public class test {
    public static void main(String[] args) throws NoSuchAlgorithmException{
        String dir = "./storeFile/Belel/"; // Root path
        String pairingFile = dir + "a.properties";
        Pairing bp = PairingFactory.getPairing(pairingFile);
        Element a = bp.getZr().newRandomElement().getImmutable();


        System.out.println(a.getLengthInBytes());
    }

}

