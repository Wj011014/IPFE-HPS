package Han;

import it.unisa.dia.gas.jpbc.Element;
import it.unisa.dia.gas.jpbc.Pairing;
import it.unisa.dia.gas.plaf.jpbc.pairing.PairingFactory;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Random;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Properties;


import static java.lang.System.out;

public class Han {

    //初始阶段


    public static void setup(String pairingFile, String paramsFile,String mskFile, String vectorFile,int n) {
        //第一个变量是公共的参数文件，第二个变量是公共变量文件，第三个变量是主私钥变量文件
        Pairing bp = PairingFactory.getPairing(pairingFile);  //用于生成群G1或者G2元素的对象
        Properties PProp =loadPropFromFile(paramsFile);
        Properties mskProp = loadPropFromFile(mskFile);  //定义一个对properties文件操作的对象
        Properties vPro = loadPropFromFile(vectorFile);
        String g0str=PProp.getProperty("g0");
        String gstr=PProp.getProperty("g");
        String g1str=PProp.getProperty("g1");
        String g2str=PProp.getProperty("g2");
        String g3str=PProp.getProperty("g3");
        String g4str=PProp.getProperty("g4");
        Element g = bp.getG1().newElementFromBytes(gstr.getBytes()).getImmutable();
        Element g0 = bp.getG1().newElementFromBytes(g0str.getBytes()).getImmutable();
        Element g1 = bp.getG1().newElementFromBytes(g1str.getBytes()).getImmutable();
        Element g2 = bp.getG1().newElementFromBytes(g2str.getBytes()).getImmutable();
        Element g3 = bp.getG1().newElementFromBytes(g3str.getBytes()).getImmutable();
        Element g4 = bp.getG1().newElementFromBytes(g4str.getBytes()).getImmutable();
        Element x1 =bp.getZr().newRandomElement().getImmutable();
        Element x2 =bp.getZr().newRandomElement().getImmutable();
        mskProp.setProperty("x1",x1.toString());
        mskProp.setProperty("x2",x2.toString());
        Element h =bp.getG1().newRandomElement().getImmutable();
        Element [] s = new Element[n];
        Element [] Y = new Element[n];
        Element X0 = bp.pairing(g,h);
        Element X1 = h.powZn(x1);
        Element X2 = h.powZn(x2);
        Element X3 = bp.pairing(g4,h).powZn(x2);
        for (int i = 0; i < n; i++)
        {
            s[i] = bp.getZr().newRandomElement().getImmutable();
            mskProp.setProperty("s"+i,s[i].toString());
            Y[i] = bp.pairing(g,h).powZn(s[i]);
            PProp.setProperty("Y"+i+1,Y[i].toString());
        }
        PProp.setProperty("g",g.toString());
        PProp.setProperty("g0",g0.toString());
        PProp.setProperty("g1",g1.toString());
        PProp.setProperty("g2",g2.toString());
        PProp.setProperty("g3",g3.toString());
        PProp.setProperty("g4",g4.toString());
        PProp.setProperty("h",h.toString());
        PProp.setProperty("X0",X0.toString());
        PProp.setProperty("X1",X1.toString());
        PProp.setProperty("X2",X2.toString());
        PProp.setProperty("X3",X3.toString());

        storePropToFile(PProp,paramsFile);

        storePropToFile(mskProp, mskFile);
    }





    public static void Encryption(String pairingFile, String paramsFile, String vectorFile, String CTFile, String randomFile,int n, double[] x) throws NoSuchAlgorithmException {
        Pairing bp=PairingFactory.getPairing(pairingFile);
        Properties CTProp =loadPropFromFile(CTFile);
        Properties PProp =loadPropFromFile(paramsFile);
        Properties vPro = loadPropFromFile(vectorFile);
        Properties randomPro = loadPropFromFile(randomFile);
        Element[] Y = new Element[n];
        String gstr = PProp.getProperty("g");
        Element g = bp.getG1().newElementFromBytes(gstr.getBytes()).getImmutable();
        String hstr = PProp.getProperty("h");
        Element h = bp.getG1().newElementFromBytes(hstr.getBytes()).getImmutable();
        String g0str = PProp.getProperty("g0");
        Element g0 = bp.getG1().newElementFromBytes(g0str.getBytes()).getImmutable();
        String g1str = PProp.getProperty("g1");
        Element g1 = bp.getG1().newElementFromBytes(g1str.getBytes()).getImmutable();
        String g2str = PProp.getProperty("g2");
        Element g2 = bp.getG1().newElementFromBytes(g2str.getBytes()).getImmutable();
        String g3str = PProp.getProperty("g3");
        Element g3 = bp.getG1().newElementFromBytes(g3str.getBytes()).getImmutable();
        String g4str = PProp.getProperty("g4");
        Element g4 = bp.getG1().newElementFromBytes(g4str.getBytes()).getImmutable();
        String X0str = PProp.getProperty("X0");
        Element X0 = bp.getG1().newElementFromBytes(X0str.getBytes()).getImmutable();
        String X1str = PProp.getProperty("X1");
        Element X1 = bp.getG1().newElementFromBytes(X1str.getBytes()).getImmutable();
        String X2str = PProp.getProperty("X2");
        Element X2 = bp.getG1().newElementFromBytes(X2str.getBytes()).getImmutable();
        String X3str = PProp.getProperty("X3");
        Element X3 = bp.getG1().newElementFromBytes(X3str.getBytes()).getImmutable();
        Element t = bp.getZr().newRandomElement().getImmutable();
        Element TE = bp.getZr().newRandomElement().getImmutable();
        Element C11 = g1.powZn(t);
        Element C21 = g2.powZn(t);
        Element C31 = g3.powZn(t);
        Element C41 = g0.powZn(t);
        Element C51 = h.powZn(t);
        Element[] C = new Element[n];
        Element[] X = new Element[n];
        for (int i = 0; i <n; i++)
        {
            String ystr= PProp.getProperty("Y"+i+1);
            X[i] = bp.getZr().newRandomElement().getImmutable();
            Y[i] = bp.getG1().newElementFromBytes(ystr.getBytes()).getImmutable();
            C[i] = Y[i].powZn(t).mulZn(X3.powZn(t.mul(TE))).mulZn(X0.powZn(X[i]));
            vPro.setProperty("x"+i, X[i].toString());
            CTProp.setProperty("C"+i,C[i].toString());
        }
        CTProp.setProperty("C11",C11.toString());
        CTProp.setProperty("C21",C21.toString());
        CTProp.setProperty("C31",C31.toString());
        CTProp.setProperty("C41",C41.toString());
        CTProp.setProperty("C51",C51.toString());

        randomPro.setProperty("t", t.toString());
        randomPro.setProperty("TE", TE.toString());

        storePropToFile(CTProp,CTFile);
        storePropToFile(randomPro,randomFile);
        storePropToFile(vPro, vectorFile);

    }
    public static void KGen(String pairingFile,String paramsFile,String mskFile,String vectorFile,String skFile,String randomFile,double[] y,int n,String ID)throws NoSuchAlgorithmException{
        Pairing bp=PairingFactory.getPairing(pairingFile);
        Properties PProp =loadPropFromFile(paramsFile);
        Properties skProp =loadPropFromFile(skFile);
        Properties vPro = loadPropFromFile(vectorFile);
        Properties mskProp = loadPropFromFile(mskFile);
        Properties randomProp =loadPropFromFile(randomFile);

        String gstr = PProp.getProperty("g");
        Element g = bp.getG1().newElementFromBytes(gstr.getBytes()).getImmutable();
        String hstr = PProp.getProperty("h");
        Element h = bp.getG1().newElementFromBytes(hstr.getBytes()).getImmutable();
        String g0str = PProp.getProperty("g0");
        Element g0 = bp.getG1().newElementFromBytes(g0str.getBytes()).getImmutable();
        String g1str = PProp.getProperty("g1");
        Element g1 = bp.getG1().newElementFromBytes(g1str.getBytes()).getImmutable();
        String g2str = PProp.getProperty("g2");
        Element g2 = bp.getG1().newElementFromBytes(g2str.getBytes()).getImmutable();
        String g3str = PProp.getProperty("g3");
        Element g3 = bp.getG1().newElementFromBytes(g3str.getBytes()).getImmutable();
        String g4str = PProp.getProperty("g4");
        Element g4 = bp.getG1().newElementFromBytes(g4str.getBytes()).getImmutable();
        String X0str = PProp.getProperty("X0");
        Element X0 = bp.getG1().newElementFromBytes(X0str.getBytes()).getImmutable();
        String X1str = PProp.getProperty("X1");
        Element X1 = bp.getG1().newElementFromBytes(X1str.getBytes()).getImmutable();
        String X2str = PProp.getProperty("X2");
        Element X2 = bp.getG1().newElementFromBytes(X2str.getBytes()).getImmutable();
        String X3str = PProp.getProperty("X3");
        Element X3 = bp.getG1().newElementFromBytes(X3str.getBytes()).getImmutable();
        String x1str = mskProp.getProperty("x1");
        Element x1 = bp.getG1().newElementFromBytes(x1str.getBytes()).getImmutable();
        String x2str = mskProp.getProperty("x2");
        Element x2 = bp.getG1().newElementFromBytes(x2str.getBytes()).getImmutable();
        Element []f = new Element[n];
        Element []s = new Element[n];
        Element r = bp.getZr().newRandomElement().getImmutable();
        Element w = bp.getZr().newRandomElement().getImmutable();
        Element sf = g;
        Element ID1 = bp.getZr().newElementFromBytes(ID.getBytes()).getImmutable();
        for (int i = 0; i < n; i++)
        {
            String sstr = mskProp.getProperty("s"+i);
            s[i] =bp.getZr().newElementFromBytes(sstr.getBytes()).getImmutable();
            f[i] = bp.getZr().newRandomElement().getImmutable();
            sf = sf.powZn(s[i].mul(f[i]));
            skProp.setProperty("f"+i,f[i].toString());
        }
        Element K1 = sf.mulZn(g1.mul(g2.powZn(ID1)).powZn(x1).mul(g3.powZn(x2))).powZn(r);
        Element K2 = X1.powZn(r);
        Element K3 = X2.powZn(r);
        Element K4 = h.powZn(r);
        Element K5 = g0.powZn(r).mulZn(g4.powZn(x2));
        skProp.setProperty("K1",K1.toString());
        skProp.setProperty("K2",K2.toString());
        skProp.setProperty("K3",K3.toString());
        skProp.setProperty("K4",K4.toString());
        skProp.setProperty("K5",K5.toString());
        randomProp.setProperty("r",r.toString());
        randomProp.setProperty("w",w.toString());
        storePropToFile(randomProp,randomFile);
        storePropToFile(vPro, vectorFile);
        storePropToFile(skProp, skFile);


    }



    public static void Dec(String pairingFile,String paramsFile,String vectorFile,String skFile,String randomFile,String CTFile,int n, Double M,String ID)throws NoSuchAlgorithmException{
        Pairing bp=PairingFactory.getPairing(pairingFile);
        Properties PProp =loadPropFromFile(paramsFile);
        Properties CTProp =loadPropFromFile(CTFile);
        Properties skProp =loadPropFromFile(skFile);
        Properties vPro = loadPropFromFile(vectorFile);
        Properties randomProp =loadPropFromFile(randomFile);

        String gstr = PProp.getProperty("g");
        Element g = bp.getG1().newElementFromBytes(gstr.getBytes()).getImmutable();
        String hstr = PProp.getProperty("h");
        Element h = bp.getG1().newElementFromBytes(hstr.getBytes()).getImmutable();
        String g0str = PProp.getProperty("g0");
        Element g0 = bp.getG1().newElementFromBytes(g0str.getBytes()).getImmutable();
        String g1str = PProp.getProperty("g1");
        Element g1 = bp.getG1().newElementFromBytes(g1str.getBytes()).getImmutable();
        String g2str = PProp.getProperty("g2");
        Element g2 = bp.getG1().newElementFromBytes(g2str.getBytes()).getImmutable();
        String g3str = PProp.getProperty("g3");
        Element g3 = bp.getG1().newElementFromBytes(g3str.getBytes()).getImmutable();
        String g4str = PProp.getProperty("g4");
        Element g4 = bp.getG1().newElementFromBytes(g4str.getBytes()).getImmutable();
        String X0str = PProp.getProperty("X0");
        Element X0 = bp.getG1().newElementFromBytes(X0str.getBytes()).getImmutable();
        String X1str = PProp.getProperty("X1");
        Element X1 = bp.getG1().newElementFromBytes(X1str.getBytes()).getImmutable();
        String X2str = PProp.getProperty("X2");
        Element X2 = bp.getG1().newElementFromBytes(X2str.getBytes()).getImmutable();
        String X3str = PProp.getProperty("X3");
        Element X3 = bp.getG1().newElementFromBytes(X3str.getBytes()).getImmutable();
       String C11str = CTProp.getProperty("C11");
        Element C11 = bp.getG1().newElementFromBytes(C11str.getBytes()).getImmutable();
        String C21str = CTProp.getProperty("C21");
        Element C21 = bp.getG1().newElementFromBytes(C21str.getBytes()).getImmutable();
        String C31str = CTProp.getProperty("C31");
        Element C31 = bp.getG1().newElementFromBytes(C31str.getBytes()).getImmutable();
        String C41str = CTProp.getProperty("C41");
        Element C41 = bp.getG1().newElementFromBytes(C41str.getBytes()).getImmutable();
        String C51str = CTProp.getProperty("C51");
        Element C51 = bp.getG1().newElementFromBytes(C51str.getBytes()).getImmutable();
        String k1srt = skProp.getProperty("K1");
        Element K1 = bp.getG1().newElementFromBytes(k1srt.getBytes()).getImmutable();
        String k2srt = skProp.getProperty("K2");
        Element K2 = bp.getG1().newElementFromBytes(k2srt.getBytes()).getImmutable();
        String k3srt = skProp.getProperty("K3");
        Element K3 = bp.getG1().newElementFromBytes(k3srt.getBytes()).getImmutable();
        String k4srt = skProp.getProperty("K4");
        Element K4 = bp.getG1().newElementFromBytes(k4srt.getBytes()).getImmutable();
        String k5srt = skProp.getProperty("K5");
        Element K5 = bp.getG1().newElementFromBytes(k5srt.getBytes()).getImmutable();
        String Testr = randomProp.getProperty("TE");
        Element TE = bp.getZr().newElementFromBytes(Testr.getBytes()).getImmutable();
        Element[] C = new Element[n];

        Element[] f = new Element[n];


        for(int i = 0; i < n; i++)
        {

            String ystr=skProp.getProperty("f"+i);
            String cstr=CTProp.getProperty("C"+i);
            f[i] = bp.getZr().newElementFromBytes(ystr.getBytes()).getImmutable();
            C[i] = bp.getZr().newElementFromBytes(cstr.getBytes()).getImmutable();
        }
        Element E1 = C[0].powZn(f[0]);
        Element ID1 = bp.getZr().newElementFromBytes(ID.getBytes()).getImmutable();
        for (int i = 1; i <n; i++)
        {
            E1 = E1.mulZn(C[i].powZn(f[i]));
        }

        Element E2 = bp.pairing(C11,K2).mul(bp.pairing(C21,K2).powZn(ID1));


        Element E3 = bp.pairing(C31,K3).mul(bp.pairing(C41,K4).powZn(TE));
        Element E4 = bp.pairing(K1,C51).mul(bp.pairing(K5,C51).powZn(TE));
        for (int i = 0; i < n; i++)
        {
            E4 = E4.powZn(f[i]);
            E3 = E3.powZn(f[i]);
        }

        Element E = E1.mulZn(E2).mulZn(E3).mulZn(E4.invert());

        Element EM = bp.pairing(g,h).powZn(bp.getZr().newElementFromBytes(String.valueOf(M).getBytes()).getImmutable());
        if (E.isEqual(bp.pairing(g,h).powZn(EM))) System.out.println("OK");

//        storePropToFile(randomProp,randomFile);

//        storePropToFile(skProp, skFile);


    }

    /*
    将程序变量数据存储到文件中
     */
    public static void storePropToFile(Properties prop, String fileName){
        try(FileOutputStream out = new FileOutputStream(fileName)){
            prop.store(out, null);
        }
        catch (IOException e) {
            e.printStackTrace();
            out.println(fileName + " save failed!");
            System.exit(-1);
        }
    }



    /*
    从文件中读取数据
     */
    public static Properties loadPropFromFile(String fileName) {
        Properties prop = new Properties();
        try (
                FileInputStream in = new FileInputStream(fileName)){
            prop.load(in);
        }
        catch (IOException e){
            e.printStackTrace();
            out.println(fileName + " load failed!");
            System.exit(-1);
        }
        return prop;
    }


    /*
    哈希函数
     */
    public static byte[] sha0(String content) throws NoSuchAlgorithmException {
        MessageDigest instance = MessageDigest.getInstance("SHA-1");
        instance.update(content.getBytes());
        return instance.digest();
    }

    public static void main(String[] args) throws NoSuchAlgorithmException {
        /*
        指定配置文件的路径
         */
        String dir = "./storeFile/Han/"; //根路径
        String pairingParametersFileName = dir + "a.properties";

        String ParameterFileName = dir + "params.properties";
        String mskFileName = dir + "msk.properties";
        String vectorFileName=dir+"vector.properties";

        String randomFileName=dir+"random.properties";
        String skFileName=dir+"sk.properties";
        String CTFileName=dir+"CT.properties";

        Random rand = new Random();

        int n = 30;
        double[] x = new double[n];
        double[] y = new double[n];
        String ID="User";
        Double M = 0.0;
        for (int i = 0; i < n; i++)
        {
            x[i] = rand.nextInt(10)+0;
            y[i] = rand.nextInt(10)+0;
            M+=x[i]*y[i];

        }
        System.out.println(M);
        long start1 = System.currentTimeMillis();
        setup(pairingParametersFileName,ParameterFileName,mskFileName,vectorFileName,n);
        long end1 = System.currentTimeMillis();
        System.out.println("Setup");
        System.out.println(end1-start1);
        long start2 = System.currentTimeMillis();
        Encryption( pairingParametersFileName, ParameterFileName, vectorFileName, CTFileName, randomFileName, n, x);
        long end2 = System.currentTimeMillis();
        System.out.println("Enc");
        System.out.println(end2-start2);
        long start3 = System.currentTimeMillis();
        KGen(pairingParametersFileName,ParameterFileName,mskFileName,vectorFileName,skFileName,randomFileName,y,n,ID);
        long end3 = System.currentTimeMillis();
        System.out.println("KGen");
        System.out.println(end3-start3);

//        System.out.println(end4-start4);
        long start5 = System.currentTimeMillis();
        Dec(pairingParametersFileName,ParameterFileName,vectorFileName,skFileName,randomFileName,CTFileName,n,M, ID);
        long end5 = System.currentTimeMillis();
        System.out.println("Dec");
        System.out.println(end5-start5);

    }


}