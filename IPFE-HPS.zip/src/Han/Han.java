package Han;

import it.unisa.dia.gas.jpbc.Element;
import it.unisa.dia.gas.jpbc.Pairing;
import it.unisa.dia.gas.plaf.jpbc.pairing.PairingFactory;

import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

/**
 * Runnable benchmark for Han et al., DFE-IP (Information Sciences 647, 2023).
 * Implements Setup, KeyGen, Enc, DKeyGen, ODec and DDec from Fig. 2.
 * The bundled Type-A pairing is symmetric (G1=G2); the paper's formulas are
 * written for a Type-3 pairing, so this is an algebraically faithful JPBC test
 * harness, not a Type-F curve reproduction of the paper's reported timings.
 */
public final class Han {
    private static final int WARMUPS = 5;
    private static final int SAMPLES = 25;
    private static final int[] DIMENSIONS = {10, 15, 20, 25,30};
    private static final String DELEGATOR = "delegator-001";
    private static final String DELEGATEE = "delegatee-001";
    private static final String PERIOD = "2026-09-28";
    private static final String CSV = "han-dfe-ip-results.csv";
    private static Pairing pairing;

    private Han() { }

    private static final class PublicParams {
        Element g, g0, g1, g2, g3, g4, h, x0, x1, x2, x3;
        Element[] y;
    }

    private static final class MasterSecret {
        Element x1, x2;
        Element[] s;
    }

    private static final class SecretKey {
        Element k1, k2, k3, k4, k5;
        Element[] f;
    }

    private static final class DelegationKey {
        Element k1, k2, k3, k4, k5;
        String period;
    }

    private static final class Ciphertext {
        Element c1Hat, c2Hat, c3Hat, c4Hat, c5Hat;
        Element[] c;
        String period;
    }

    private static final class SetupResult {
        final PublicParams pp;
        final MasterSecret msk;
        SetupResult(PublicParams pp, MasterSecret msk) { this.pp = pp; this.msk = msk; }
    }

    private static Element randomScalar() {
        Element z;
        do { z = pairing.getZr().newRandomElement(); } while (z.isZero());
        return z.getImmutable();
    }

    private static Element hashToZr(String input) {
        try {
            byte[] digest = MessageDigest.getInstance("SHA-256")
                    .digest(input.getBytes(StandardCharsets.UTF_8));
            return pairing.getZr().newElementFromHash(digest, 0, digest.length).getImmutable();
        } catch (Exception ex) {
            throw new IllegalStateException("SHA-256 unavailable", ex);
        }
    }

    private static Element scalar(long value) {
        return pairing.getZr().newElement(BigInteger.valueOf(value)).getImmutable();
    }

    private static SetupResult setup(int n) {
        PublicParams pp = new PublicParams();
        MasterSecret msk = new MasterSecret();
        pp.g = pairing.getG1().newRandomElement().getImmutable();
        pp.g0 = pairing.getG1().newRandomElement().getImmutable();
        pp.g1 = pairing.getG1().newRandomElement().getImmutable();
        pp.g2 = pairing.getG1().newRandomElement().getImmutable();
        pp.g3 = pairing.getG1().newRandomElement().getImmutable();
        pp.g4 = pairing.getG1().newRandomElement().getImmutable();
        pp.h = pairing.getG2().newRandomElement().getImmutable();
        msk.x1 = randomScalar();
        msk.x2 = randomScalar();
        msk.s = new Element[n];
        pp.y = new Element[n];
        pp.x0 = pairing.pairing(pp.g, pp.h).getImmutable();
        pp.x1 = pp.h.powZn(msk.x1).getImmutable();
        pp.x2 = pp.h.powZn(msk.x2).getImmutable();
        pp.x3 = pairing.pairing(pp.g4, pp.h).powZn(msk.x2).getImmutable();
        for (int i = 0; i < n; i++) {
            msk.s[i] = randomScalar();
            pp.y[i] = pp.x0.powZn(msk.s[i]).getImmutable();
        }
        return new SetupResult(pp, msk);
    }

    private static SecretKey keyGen(PublicParams pp, MasterSecret msk, Element[] f, String id) {
        SecretKey sk = new SecretKey();
        sk.f = f;
        Element dotSf = pairing.getZr().newZeroElement();
        for (int i = 0; i < f.length; i++) dotSf.add(msk.s[i].duplicate().mul(f[i]));
        Element r = randomScalar();
        Element hid = hashToZr("ID:" + id);
        Element idPart = pp.g1.mul(pp.g2.powZn(hid)).powZn(msk.x1)
                .mul(pp.g3.powZn(msk.x2)).powZn(r);
        sk.k1 = pp.g.powZn(dotSf).mul(idPart).getImmutable();
        sk.k2 = pp.x1.powZn(r).getImmutable();
        sk.k3 = pp.x2.powZn(r).getImmutable();
        sk.k4 = pp.h.powZn(r).getImmutable();
        sk.k5 = pp.g0.powZn(r).mul(pp.g4.powZn(msk.x2)).getImmutable();
        return sk;
    }

    private static Ciphertext encrypt(PublicParams pp, long[] m, String period) {
        Ciphertext ct = new Ciphertext();
        ct.period = period;
        Element t = randomScalar();
        Element ht = hashToZr("TIME:" + period);
        ct.c1Hat = pp.g1.powZn(t).getImmutable();
        ct.c2Hat = pp.g2.powZn(t).getImmutable();
        ct.c3Hat = pp.g3.powZn(t).getImmutable();
        ct.c4Hat = pp.g0.powZn(t).getImmutable();
        ct.c5Hat = pp.h.powZn(t).getImmutable();
        ct.c = new Element[m.length];
        Element timeBlind = pp.x3.powZn(t.duplicate().mul(ht));
        for (int i = 0; i < m.length; i++) {
            ct.c[i] = pp.y[i].powZn(t).mul(timeBlind)
                    .mul(pp.x0.powZn(scalar(m[i]))).getImmutable();
        }
        return ct;
    }

    private static DelegationKey delegate(PublicParams pp, SecretKey sk,
                                          String delegatee, String period) {
        DelegationKey dk = new DelegationKey();
        dk.period = period;
        Element z = randomScalar();
        Element hPeriod = hashToZr("TIME:" + period);
        Element hId = hashToZr("ID:" + delegatee);
        Element zHid = z.duplicate().mul(hId);
        dk.k1 = sk.k1;
        dk.k2 = sk.k2;
        dk.k3 = sk.k3;
        dk.k4 = sk.k4.powZn(hPeriod).mul(pp.h.powZn(zHid)).getImmutable();
        dk.k5 = sk.k5.powZn(hPeriod).mul(pp.g0.powZn(zHid)).getImmutable();
        return dk;
    }

    private static Element decrypt(PublicParams pp, SecretKey sk, Ciphertext ct, String id) {
        return decryptCore(pp, sk.f, sk.k1, sk.k2, sk.k3, sk.k4, sk.k5, ct, id, false);
    }

    private static Element decryptDelegated(PublicParams pp, SecretKey sk, DelegationKey dk,
                                            Ciphertext ct, String delegatorId, String period) {
        if (!period.equals(ct.period) || !period.equals(dk.period)) {
            throw new IllegalArgumentException("delegation period mismatch");
        }
        return decryptCore(pp, sk.f, dk.k1, dk.k2, dk.k3, dk.k4, dk.k5, ct,
                delegatorId, true);
    }

    private static Element decryptCore(PublicParams pp, Element[] f,
                                       Element k1, Element k2, Element k3,
                                       Element k4, Element k5, Ciphertext ct,
                                       String id, boolean delegated) {
        Element result = pairing.getGT().newOneElement();
        Element sumF = pairing.getZr().newZeroElement();
        for (int i = 0; i < f.length; i++) {
            result.mul(ct.c[i].powZn(f[i]));
            sumF.add(f[i]);
        }
        Element hId = hashToZr("ID:" + id);
        Element hTime = hashToZr("TIME:" + ct.period);
        result.mul(pairing.pairing(ct.c1Hat, k2));
        result.mul(pairing.pairing(ct.c2Hat, k2).powZn(hId));
        result.mul(pairing.pairing(ct.c3Hat, k3));
        Element weightedTime = hTime.duplicate().mul(sumF);
        Element c4Pair = pairing.pairing(ct.c4Hat, k4);
        Element k5Pair = pairing.pairing(k5, ct.c5Hat);
        if (delegated) {
            result.mul(c4Pair.powZn(sumF));
            result.mul(k5Pair.powZn(sumF).invert());
        } else {
            result.mul(c4Pair.powZn(weightedTime));
            result.mul(k5Pair.powZn(weightedTime).invert());
        }
        result.mul(pairing.pairing(k1, ct.c5Hat).invert());
        return result.getImmutable();
    }

    private static long medianNanos(Runnable operation) {
        for (int i = 0; i < WARMUPS; i++) operation.run();
        List<Long> times = new ArrayList<>(SAMPLES);
        for (int i = 0; i < SAMPLES; i++) {
            long start = System.nanoTime();
            operation.run();
            times.add(System.nanoTime() - start);
        }
        Collections.sort(times);
        return times.get(times.size() / 2);
    }

    private static Element[] vector(int n) {
        Element[] v = new Element[n];
        for (int i = 0; i < n; i++) v[i] = scalar((i % 5) + 1);
        return v;
    }

    private static long[] message(int n) {
        long[] m = new long[n];
        for (int i = 0; i < n; i++) m[i] = (i % 5) + 1;
        return m;
    }

    private static Element expected(PublicParams pp, Element[] f, long[] m) {
        Element dot = pairing.getZr().newZeroElement();
        for (int i = 0; i < f.length; i++) dot.add(f[i].duplicate().mul(scalar(m[i])));
        return pp.x0.powZn(dot).getImmutable();
    }

    public static void main(String[] args) throws Exception {
        String pairingFile = args.length > 0 ? args[0] : "./storeFile/Han/a.properties";
        String csvFile = args.length > 1 ? args[1] : CSV;
        PairingFactory.getInstance().setUsePBCWhenPossible(false);
        pairing = PairingFactory.getPairing(pairingFile);

        try (PrintWriter csv = new PrintWriter(new OutputStreamWriter(
                new FileOutputStream(csvFile), StandardCharsets.UTF_8))) {
            csv.println("dimension,setup_ms,keygen_ms,encryption_ms,dkeygen_ms,odec_ms,ddec_ms,correct_original,correct_delegated");
            System.out.println("n,Setup(ms),KeyGen(ms),Encryption(ms),DKeyGen(ms),ODec(ms),DDec(ms),Correct");
            for (int n : DIMENSIONS) {
                SetupResult initial = setup(n);
                Element[] f = vector(n);
                long[] m = message(n);
                Ciphertext ct = encrypt(initial.pp, m, PERIOD);
                SecretKey sk = keyGen(initial.pp, initial.msk, f, DELEGATOR);
                DelegationKey dk = delegate(initial.pp, sk, DELEGATEE, PERIOD);
                Element target = expected(initial.pp, f, m);
                boolean correctOriginal = decrypt(initial.pp, sk, ct, DELEGATOR).isEqual(target);
                boolean correctDelegated = decryptDelegated(initial.pp, sk, dk, ct,
                        DELEGATOR, PERIOD).isEqual(target);
                if (!correctOriginal || !correctDelegated) {
                    throw new IllegalStateException("correctness failed at n=" + n
                            + " (original=" + correctOriginal + ", delegated=" + correctDelegated + ")");
                }

                long setupNs = medianNanos(() -> setup(n));
                long keygenNs = medianNanos(() -> keyGen(initial.pp, initial.msk, f, DELEGATOR));
                long encNs = medianNanos(() -> encrypt(initial.pp, m, PERIOD));
                long dkeygenNs = medianNanos(() -> delegate(initial.pp, sk, DELEGATEE, PERIOD));
                long odecNs = medianNanos(() -> decrypt(initial.pp, sk, ct, DELEGATOR));
                long ddecNs = medianNanos(() -> decryptDelegated(initial.pp, sk, dk, ct,
                        DELEGATOR, PERIOD));
                double[] ms = {setupNs / 1e6, keygenNs / 1e6, encNs / 1e6,
                        dkeygenNs / 1e6, odecNs / 1e6, ddecNs / 1e6};
                System.out.printf(Locale.ROOT, "%d,%.3f,%.3f,%.3f,%.3f,%.3f,%.3f,%s%n",
                        n, ms[0], ms[1], ms[2], ms[3], ms[4], ms[5], "PASS");
                csv.printf(Locale.ROOT, "%d,%.6f,%.6f,%.6f,%.6f,%.6f,%.6f,%s,%s%n",
                        n, ms[0], ms[1], ms[2], ms[3], ms[4], ms[5],
                        correctOriginal, correctDelegated);
            }
        }
        System.out.println("CSV: " + csvFile);
        System.out.printf(Locale.ROOT, "Median of %d samples after %d warmups; correctness includes direct/delegated pairing outputs.%n",
                SAMPLES, WARMUPS);
    }
}
