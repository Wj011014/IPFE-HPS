package Zhu;

import it.unisa.dia.gas.jpbc.Element;
import it.unisa.dia.gas.jpbc.Pairing;
import it.unisa.dia.gas.plaf.jpbc.pairing.PairingFactory;

import java.io.BufferedWriter;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;

/**
 * JPBC benchmark for Zhu et al., "Revocable-Hierarchical-Identity-Based
 * Inner Product Function Encryption in Smart Healthcare" (IEEE IoT-J 2025).
 *
 * Paper notation note: the construction paragraph prints g1=g, but the key
 * correctness derivation requires e(g,g2)^(alpha*s*sum(y)) to cancel the
 * ciphertext mask. This implementation follows that derivation and sets
 * g1=g^alpha, g0=g2^alpha, and u=e(g1,g2). It also interprets g0^y for a
 * vector predicate as g0^(sum_i y_i), matching the single K0 component and
 * C1^y mask in the paper. Those ambiguities should be disclosed with results.
 *
 * This measures Setup, direct KeyGen, Enc and Dec. Hierarchy depth l=20 and
 * identity depth k=10 are fixed while vector dimension n varies.
 */
public final class ZhuHIBIPFEBenchmark {
    private static final int[] DIMENSIONS = {10, 15, 20, 25};
    private static final int L = 20;
    private static final int K = 10;
    private static final int WARMUPS = 5;
    private static final int SAMPLES = 25;

    private final Pairing pairing;
    private final String pairingFile;

    private ZhuHIBIPFEBenchmark(String pairingFile) {
        this.pairingFile = pairingFile;
        PairingFactory.getInstance().setUsePBCWhenPossible(true);
        this.pairing = PairingFactory.getPairing(pairingFile);
    }

    private static final class SetupResult {
        final Element g, g2, g3, g1, g0, u;
        final Element[] h;
        SetupResult(Element g, Element g2, Element g3, Element g1,
                    Element g0, Element u, Element[] h) {
            this.g=g; this.g2=g2; this.g3=g3; this.g1=g1; this.g0=g0;
            this.u=u; this.h=h;
        }
    }

    private static final class PrivateKey {
        final Element[] y, delegatedComponents;
        final Element k0, k1;
        PrivateKey(Element[] y, Element k0, Element k1, Element[] delegatedComponents) {
            this.y=y; this.k0=k0; this.k1=k1; this.delegatedComponents=delegatedComponents;
        }
    }

    private static final class Ciphertext {
        final Element[] c1;
        final Element c2, c3;
        Ciphertext(Element[] c1, Element c2, Element c3) {
            this.c1=c1; this.c2=c2; this.c3=c3;
        }
    }

    private Element randomScalar() { return pairing.getZr().newRandomElement().getImmutable(); }

    /** Setup(1^lambda,l). */
    private SetupResult setup() {
        Element g=pairing.getG1().newRandomElement().getImmutable();
        Element g2=pairing.getG1().newRandomElement().getImmutable();
        Element g3=pairing.getG1().newRandomElement().getImmutable();
        Element alpha=randomScalar();
        Element g1=g.powZn(alpha).getImmutable();
        Element g0=g2.powZn(alpha).getImmutable();
        Element u=pairing.pairing(g1,g2).getImmutable();
        Element[] h=new Element[L];
        for (int i=0;i<L;i++) h[i]=pairing.getG1().newRandomElement().getImmutable();
        return new SetupResult(g,g2,g3,g1,g0,u,h);
    }

    private Element identityBase(SetupResult pp, int[] id) {
        Element b=pp.g3.duplicate();
        for (int i=0;i<id.length;i++)
            b=b.mul(pp.h[i].powZn(pairing.getZr().newElement(id[i])));
        return b.getImmutable();
    }

    /** KeyGen(msk,id,y): direct issuance, with S_{k+1}...S_l retained. */
    private PrivateKey keyGen(SetupResult pp, int[] id, Element[] y) {
        Element r=randomScalar();
        Element ySum=pairing.getZr().newZeroElement();
        for (Element yi:y) ySum.add(yi);
        Element k0=pp.g0.powZn(ySum).mul(identityBase(pp,id).powZn(r)).getImmutable();
        Element k1=pp.g.powZn(r).getImmutable();
        Element[] trailing=new Element[L-id.length];
        for (int i=id.length;i<L;i++) trailing[i-id.length]=pp.h[i].powZn(r).getImmutable();
        return new PrivateKey(y.clone(),k0,k1,trailing);
    }

    /** Enc(x,id): each C1_i = u^(x_i+s), C2=g^s, C3=H_id^s. */
    private Ciphertext encrypt(SetupResult pp, int[] id, Element[] x) {
        Element s=randomScalar();
        Element[] c1=new Element[x.length];
        for (int i=0;i<x.length;i++)
            c1[i]=pp.u.powZn(x[i]).mul(pp.u.powZn(s)).getImmutable();
        Element c2=pp.g.powZn(s).getImmutable();
        Element c3=identityBase(pp,id).powZn(s).getImmutable();
        return new Ciphertext(c1,c2,c3);
    }

    /** Dec: return the GT encoding u^<x,y>. */
    private Element decrypt(Ciphertext ct, PrivateKey sk) {
        Element a1=pairing.getGT().newOneElement();
        for (int i=0;i<sk.y.length;i++) a1.mul(ct.c1[i].powZn(sk.y[i]));
        Element a2=pairing.pairing(ct.c3,sk.k1);
        Element a3=pairing.pairing(ct.c2,sk.k0);
        return a1.mul(a2).div(a3).getImmutable();
    }

    private double medianMs(Runnable task) {
        for (int i=0;i<WARMUPS;i++) task.run();
        long[] ns=new long[SAMPLES];
        for (int i=0;i<SAMPLES;i++) {
            long start=System.nanoTime(); task.run(); ns[i]=System.nanoTime()-start;
        }
        Arrays.sort(ns);
        return ns[ns.length/2]/1_000_000.0;
    }

    private void run(String csvName) throws Exception {
        Path csv=Paths.get(csvName);
        if (csv.getParent()!=null) Files.createDirectories(csv.getParent());
        try (BufferedWriter out=Files.newBufferedWriter(csv,StandardCharsets.UTF_8)) {
            out.write("n,l,k,setup_ms,encryption_ms,keygen_ms,decryption_ms,inner_product,correct\n");
            for (int n:DIMENSIONS) {
                double setupMs=medianMs(this::setup);
                SetupResult pp=setup();
                int[] id=new int[K];
                for (int i=0;i<K;i++) id[i]=i+1;
                Element[] x=new Element[n], y=new Element[n];
                long dot=0;
                for (int i=0;i<n;i++) {
                    int xv=1+i%5, yv=1+(i+2)%5;
                    x[i]=pairing.getZr().newElement(xv).getImmutable();
                    y[i]=pairing.getZr().newElement(yv).getImmutable();
                    dot+=(long)xv*yv;
                }
                Ciphertext ct=encrypt(pp,id,x);
                PrivateKey sk=keyGen(pp,id,y);
                double encMs=medianMs(()->encrypt(pp,id,x));
                double keyMs=medianMs(()->keyGen(pp,id,y));
                double decMs=medianMs(()->decrypt(ct,sk));
                Element decResult=decrypt(ct,sk);
                Element expectedResult=pp.u.powZn(pairing.getZr().newElement(BigInteger.valueOf(dot)));
                boolean correct=decResult.isEqual(expectedResult);
                out.write(String.format(Locale.US,"%d,%d,%d,%.6f,%.6f,%.6f,%.6f,%d,%s%n",
                        n,L,K,setupMs,encMs,keyMs,decMs,dot,correct));
                out.flush();
                System.out.printf(Locale.US,
                        "n=%d l=%d k=%d Setup=%.6f ms Enc=%.6f ms KeyGen=%.6f ms Dec=%.6f ms <x,y>=%d correct=%s%n",
                        n,L,K,setupMs,encMs,keyMs,decMs,dot,correct);
            }
        }
        System.out.println("CSV="+csv.toAbsolutePath());
        System.out.printf("JPBC=%s, warmups=%d, samples=%d%n",pairingFile,WARMUPS,SAMPLES);
    }

    public static void main(String[] args) throws Exception {
        String params=args.length>0?args[0]:"storeFile/Ours_File/a.properties";
        String csv=args.length>1?args[1]:"zhu-hib-ipfe-results.csv";
        new ZhuHIBIPFEBenchmark(params).run(csv);
    }
}

