package Du;

import it.unisa.dia.gas.jpbc.Element;
import it.unisa.dia.gas.jpbc.Pairing;
import it.unisa.dia.gas.plaf.jpbc.pairing.PairingFactory;

import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;

/**
 * PPDTFE-IP core-operation benchmark in the style of Belel.java.
 *
 * Uses the project's JPBC pairing file and in-memory elements. The generic
 * Sigma proof and signature interfaces in the paper are not specified enough
 * to reproduce exactly; their proof/sign/verify costs are therefore excluded.
 * The provided a.properties is Type A (symmetric), while the paper describes
 * Type-III BN. Results from this setup are an independent core-algebra
 * benchmark, not a bit-for-bit reproduction of the paper's platform.
 */
public final class Du {
    private static final int AUTHORITIES = 3;
    private static final int TRACERS = 3;
    private static final int WARMUPS = 5;
    private static final int SAMPLES = 25;
    private static final int[] DIMENSIONS = {10, 15, 20, 25,30};

    private final Pairing pairing;
    private final String pairingFile;

    private Du(String pairingFile) {
        this.pairingFile = pairingFile;
        this.pairing = PairingFactory.getPairing(pairingFile);
    }

    private static final class Authority {
        final Element gamma;
        final Element[] s;
        final Element H;
        final Element[] Q;
        Authority(Element gamma, Element[] s, Element H, Element[] Q) {
            this.gamma = gamma; this.s = s; this.H = H; this.Q = Q;
        }
    }

    private static final class SystemState {
        final Element g0, g1, g2, h, hId, hTr, v, G, pkTrace;
        final Element[] traceShares;
        final Authority[] authorities;
        SystemState(Element g0, Element g1, Element g2, Element h, Element hId,
                    Element hTr, Element v, Element G, Element pkTrace,
                    Element[] traceShares, Authority[] authorities) {
            this.g0=g0; this.g1=g1; this.g2=g2; this.h=h; this.hId=hId;
            this.hTr=hTr; this.v=v; this.G=G; this.pkTrace=pkTrace;
            this.traceShares=traceShares; this.authorities=authorities;
        }
    }

    private static final class UserState {
        final Element d, rho, aux, commitment, traceC1, traceC2;
        UserState(Element d, Element rho, Element aux, Element commitment,
                  Element traceC1, Element traceC2) {
            this.d=d; this.rho=rho; this.aux=aux; this.commitment=commitment;
            this.traceC1=traceC1; this.traceC2=traceC2;
        }
    }

    private static final class Ciphertext {
        final Element[] C;
        final Element Cn1, Cn2, Cn3;
        Ciphertext(Element[] C, Element Cn1, Element Cn2, Element Cn3) {
            this.C=C; this.Cn1=Cn1; this.Cn2=Cn2; this.Cn3=Cn3;
        }
    }

    private static final class KeyShare {
        final Element K1, K2;
        KeyShare(Element K1, Element K2) { this.K1=K1; this.K2=K2; }
    }

    private Element zrRandom() { return pairing.getZr().newRandomElement().getImmutable(); }
    private Element one(int group) {
        if (group == 1) return pairing.getG1().newOneElement().getImmutable();
        if (group == 2) return pairing.getG2().newOneElement().getImmutable();
        return pairing.getGT().newOneElement().getImmutable();
    }
    private Element sumProducts(Element[] a, Element[] b) {
        Element acc = pairing.getZr().newZeroElement();
        for (int k=0;k<a.length;k++) acc = acc.add(a[k].duplicate().mul(b[k]));
        return acc.getImmutable();
    }

    /** Setup + independent authority setup; tracing shares are Shamir evaluations. */
    private SystemState setup(int n) {
        Element g0=pairing.getG1().newRandomElement().getImmutable();
        Element g1=pairing.getG1().newRandomElement().getImmutable();
        Element g2=pairing.getG1().newRandomElement().getImmutable();
        Element h=pairing.getG2().newRandomElement().getImmutable();
        Element hId=pairing.getG2().newRandomElement().getImmutable();
        Element hTr=pairing.getG2().newRandomElement().getImmutable();
        Element v=pairing.getG2().newRandomElement().getImmutable();
        Element G=pairing.pairing(g0,h).getImmutable();

        Element[] poly=new Element[TRACERS];
        for (int i=0;i<poly.length;i++) poly[i]=zrRandom();
        Element[] shares=new Element[TRACERS];
        for (int x=1;x<=TRACERS;x++) {
            Element y=poly[poly.length-1];
            for (int j=poly.length-2;j>=0;j--)
                y=y.mul(pairing.getZr().newElement(x)).add(poly[j]);
            shares[x-1]=y.getImmutable();
        }
        Element pkTrace=hTr.powZn(poly[0]).getImmutable();

        Authority[] auth=new Authority[AUTHORITIES];
        for (int i=0;i<AUTHORITIES;i++) {
            Element gamma=zrRandom();
            Element[] s=new Element[n];
            Element[] Q=new Element[n];
            for (int k=0;k<n;k++) {
                s[k]=zrRandom();
                Q[k]=G.powZn(s[k]).getImmutable();
            }
            Element H=h.powZn(gamma).getImmutable();
            auth[i]=new Authority(gamma,s,H,Q);
        }
        return new SystemState(g0,g1,g2,h,hId,hTr,v,G,pkTrace,shares,auth);
    }

    /** User registration components used by PPKeyGen and decryption. */
    private UserState register(SystemState st) {
        Element d=zrRandom(), rho=zrRandom();
        Element aux=st.g2.powZn(d).getImmutable();
        Element commitment=aux.mul(st.v.powZn(rho)).getImmutable();
        Element tag=st.hId.powZn(d).getImmutable();
        Element traceC1=st.hTr.powZn(rho).getImmutable();
        Element traceC2=tag.mul(st.pkTrace.powZn(rho)).getImmutable();
        return new UserState(d,rho,aux,commitment,traceC1,traceC2);
    }

    /** Encrypt, following Algorithms 4 and equations (11)-(12), I=[N]. */
    private Ciphertext encrypt(SystemState st, Element[] message) {
        Element w=zrRandom();
        Element[] C=new Element[message.length];
        for (int k=0;k<message.length;k++) {
            Element q=one(3);
            for (Authority a:st.authorities) q=q.mul(a.Q[k]);
            C[k]=q.powZn(w).mul(st.G.powZn(message[k])).getImmutable();
        }
        Element aggH=one(2);
        for (Authority a:st.authorities) aggH=aggH.mul(a.H);
        Element Cn1=st.h.powZn(w).getImmutable();
        Element Cn2=aggH.powZn(w).getImmutable();
        Element Cn3=st.g1.powZn(w).getImmutable();
        return new Ciphertext(C,Cn1,Cn2,Cn3);
    }

    /**
     * Core PPKeyGen algebra (Algorithms 5-6), with all authorities issuing
     * shares for one user. ZK proofs, signatures, and their verification are
     * omitted because the paper leaves those interfaces generic.
     */
    private KeyShare[] keyGen(SystemState st, UserState user, Element[] f) {
        KeyShare[] keys=new KeyShare[st.authorities.length];
        for (int i=0;i<st.authorities.length;i++) {
            Authority a=st.authorities[i];
            Element t=zrRandom(), tp=zrRandom();
            Element dot=sumProducts(a.s,f);
            Element A1=st.g1.powZn(t).mul(st.g2.powZn(user.d)).getImmutable();
            Element A2=a.H.powZn(t).getImmutable();
            Element B1=st.g0.powZn(dot)
                    .mul(A1.powZn(a.gamma))
                    .mul(st.g1.powZn(a.gamma.duplicate().mul(tp)))
                    .getImmutable();
            Element B2=a.H.powZn(tp).getImmutable();
            Element totalT=t.duplicate().add(tp).getImmutable();
            Element K1=B1;
            Element K2=A2.mul(B2).getImmutable();
            // Keep totalT in the computation as prescribed by PPKeyGen.
            if (totalT.isZero()) throw new IllegalStateException("Unexpected zero key randomizer");
            keys[i]=new KeyShare(K1,K2);
        }
        return keys;
    }

    /** Decrypt and recover bounded nonnegative inner products by a short DLog. */
    private long decrypt(SystemState st, UserState user, Ciphertext ct,
                         KeyShare[] keys, Element[] f, long maxResult) {
        Element z=one(3);
        for (int k=0;k<f.length;k++) z=z.mul(ct.C[k].powZn(f[k]));
        Element productK1=one(1), productK2=one(2);
        for (KeyShare key:keys) {
            productK1=productK1.mul(key.K1);
            productK2=productK2.mul(key.K2);
        }
        Element numerator=z
                .mul(pairing.pairing(ct.Cn3,productK2))
                .mul(pairing.pairing(st.g2,ct.Cn2).powZn(user.d));
        Element denominator=pairing.pairing(productK1,ct.Cn1);
        Element result=numerator.mul(denominator.invert()).getImmutable();
        Element probe=one(3);
        for (long v=0;v<=maxResult;v++) {
            if (probe.isEqual(result)) return v;
            probe=probe.mul(st.G);
        }
        throw new IllegalStateException("Bounded discrete log failed; check correctness or bound");
    }

    private static double medianMillis(List<Long> samples) {
        long[] a=new long[samples.size()];
        for (int i=0;i<a.length;i++) a[i]=samples.get(i);
        Arrays.sort(a);
        return a[a.length/2]/1_000_000.0;
    }

    private double measure(Runnable action) {
        for (int i=0;i<WARMUPS;i++) action.run();
        List<Long> samples=new ArrayList<>();
        for (int i=0;i<SAMPLES;i++) {
            long start=System.nanoTime(); action.run();
            samples.add(System.nanoTime()-start);
        }
        return medianMillis(samples);
    }

    private void run(String outputCsv) throws IOException {
        Path output=Paths.get(outputCsv);
        if (output.getParent()!=null) Files.createDirectories(output.getParent());
        try (BufferedWriter w=Files.newBufferedWriter(output,StandardCharsets.UTF_8)) {
            w.write("n,setup_ms,encryption_ms,keygen_ms,decryption_ms,correct\n");
            for (int n:DIMENSIONS) {
                final int dim=n;
                final SystemState[] setupHolder=new SystemState[1];
                double setupMs=measure(()->setupHolder[0]=setup(dim));
                SystemState st=setupHolder[0];
                Element[] m=new Element[n], f=new Element[n];
                long dot=0, bound=0;
                for (int k=0;k<n;k++) {
                    int mv=1+(k%5), fv=1+((k+2)%5);
                    m[k]=pairing.getZr().newElement(mv).getImmutable();
                    f[k]=pairing.getZr().newElement(fv).getImmutable();
                    dot+=(long)mv*fv; bound+=Math.max(0L,(long)mv*fv);
                }
                UserState user=register(st);
                Ciphertext ct=encrypt(st,m);
                KeyShare[] keys=keyGen(st,user,f);
                final long expectedDot=dot;
                final long dlogBound=bound;
                double encMs=measure(()->encrypt(st,m));
                double keyMs=measure(()->keyGen(st,user,f));
                double decMs=measure(()->{
                    long recovered=decrypt(st,user,ct,keys,f,dlogBound);
                    if (recovered!=expectedDot) throw new IllegalStateException("Wrong inner product");
                });
                long recovered=decrypt(st,user,ct,keys,f,dlogBound);
                boolean correct=recovered==expectedDot;
                w.write(String.format(Locale.US,"%d,%.6f,%.6f,%.6f,%.6f,%s%n",
                        n,setupMs,encMs,keyMs,decMs,correct));
                w.flush();
                System.out.printf(Locale.US,
                        "n=%d Setup=%.6f ms Encryption=%.6f ms KeyGen=%.6f ms Decryption=%.6f ms correct=%s%n",
                        n,setupMs,encMs,keyMs,decMs,correct);
            }
        }
        System.out.println("CSV written to: " + output.toAbsolutePath());
        System.out.printf("JPBC pairing file: %s; authorities=%d; tracers=%d; samples=%d; warmups=%d%n",
                pairingFile,AUTHORITIES,TRACERS,SAMPLES,WARMUPS);
    }

    public static void main(String[] args) throws Exception {
        String pairingFile=args.length>0?args[0]:"storeFile/Du/a.properties";
        String outputCsv=args.length>1?args[1]:"ppdtfe-ip-results.csv";
        new Du(pairingFile).run(outputCsv);
    }
}
