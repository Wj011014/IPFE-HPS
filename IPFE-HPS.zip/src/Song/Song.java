package Song;

import it.unisa.dia.gas.jpbc.Element;
import it.unisa.dia.gas.jpbc.Pairing;
import it.unisa.dia.gas.plaf.jpbc.pairing.PairingFactory;

import java.io.BufferedWriter;
import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

/**
 * Benchmark implementation of Song et al., HID-PK-IPFE (Information Sciences,
 * 573 (2021)), based on the construction in the supplied Song.java source.
 * Type-A JPBC parameters are used. File serialization is excluded from timing.
 */
public final class Song {
    private static final int[] DIMENSIONS={10,15,20,25,30};
    private static final int D=10, LEVEL=8, WARMUPS=5, SAMPLES=25, MAX_INNER_PRODUCT=10000;

    private final Pairing pairing;
    private final String pairingFile;
    private Song(String pairingFile) {
        this.pairingFile=pairingFile;
        PairingFactory.getInstance().setUsePBCWhenPossible(true);
        this.pairing=PairingFactory.getPairing(pairingFile);
    }

    private static final class PublicParams {
        final Element g,ga,egg;
        final Element[] u,h;
        PublicParams(Element g,Element ga,Element egg,Element[] u,Element[] h) {
            this.g=g; this.ga=ga; this.egg=egg; this.u=u; this.h=h;
        }
    }
    private static final class SetupResult {
        final PublicParams pp; final Element alpha;
        SetupResult(PublicParams pp,Element alpha) { this.pp=pp; this.alpha=alpha; }
    }
    private static final class SecretKey {
        final Element[] ids,y;
        final Element kh,kt;
        final Element[] kSuffix;
        SecretKey(Element[] ids,Element[] y,Element kh,Element kt,Element[] kSuffix) {
            this.ids=ids; this.y=y; this.kh=kh; this.kt=kt; this.kSuffix=kSuffix;
        }
    }
    private static final class Ciphertext {
        final Element[] ids,cx;
        final Element cr,cu;
        Ciphertext(Element[] ids,Element cr,Element cu,Element[] cx) {
            this.ids=ids; this.cr=cr; this.cu=cu; this.cx=cx;
        }
    }

    private Element randomScalarNonzero() {
        Element z;
        do { z=pairing.getZr().newRandomElement(); } while (z.isZero());
        return z.getImmutable();
    }

    /** Setup(1^k,n,d): PK contains g,g^alpha,u_1...u_{d+1},h_1...h_n. */
    private SetupResult setup(int n) {
        Element g=pairing.getG1().newRandomElement().getImmutable();
        Element alpha=randomScalarNonzero();
        Element ga=g.powZn(alpha).getImmutable();
        Element egg=pairing.pairing(g,g).getImmutable();
        Element[] u=new Element[D+2], h=new Element[n];
        for (int i=1;i<=D+1;i++) u[i]=pairing.getG1().newRandomElement().getImmutable();
        for (int i=0;i<n;i++) h[i]=pairing.getG1().newRandomElement().getImmutable();
        return new SetupResult(new PublicParams(g,ga,egg,u,h),alpha);
    }

    private Element idBase(PublicParams pp,Element[] ids) {
        Element base=pp.u[D+1].duplicate();
        for (int i=0;i<ids.length;i++) base=base.mul(pp.u[i+1].powZn(ids[i]));
        return base.getImmutable();
    }

    /** Enc: Cx_i=e(g,g)^x_i e(g^alpha,h_i)^r; Cr=g^r; Cu=U_id^r. */
    private Ciphertext encrypt(PublicParams pp,Element[] ids,Element[] x) {
        Element r=randomScalarNonzero();
        Element[] cx=new Element[x.length];
        for (int i=0;i<x.length;i++)
            cx[i]=pp.egg.powZn(x[i]).mul(pairing.pairing(pp.ga,pp.h[i]).powZn(r)).getImmutable();
        Element cr=pp.g.powZn(r).getImmutable();
        Element cu=idBase(pp,ids).powZn(r).getImmutable();
        return new Ciphertext(ids.clone(),cr,cu,cx);
    }

    /** KeyGen: Kh=(prod h_i^y_i)^alpha * U_id^(-t), Kt=g^t. */
    private SecretKey keyGen(SetupResult st,Element[] ids,Element[] y) {
        Element t=randomScalarNonzero();
        Element hy=pairing.getG1().newOneElement();
        for (int i=0;i<y.length;i++) hy=hy.mul(st.pp.h[i].powZn(y[i]));
        Element kh=hy.powZn(st.alpha).mul(idBase(st.pp,ids).powZn(t.duplicate().negate())).getImmutable();
        Element kt=st.pp.g.powZn(t).getImmutable();
        Element[] suffix=new Element[D+1];
        for (int i=ids.length+1;i<=D;i++) suffix[i]=st.pp.u[i].powZn(t).getImmutable();
        return new SecretKey(ids.clone(),y.clone(),kh,kt,suffix);
    }

    /** Delegate a key for depth ell to a child identity at depth ell+1. */
    private SecretKey delegate(PublicParams pp,SecretKey parent,Element childId) {
        int ell=parent.ids.length;
        if (ell>=D) throw new IllegalArgumentException("maximum hierarchy depth reached");
        Element t0=randomScalarNonzero();
        Element[] childIds=Arrays.copyOf(parent.ids,ell+1);
        childIds[ell]=childId;
        Element kNext=parent.kSuffix[ell+1];
        if (kNext==null) throw new IllegalArgumentException("missing delegation component K_{ell+1}");
        Element kh=parent.kh.mul(kNext.powZn(childId.duplicate().negate()))
                .mul(idBase(pp,childIds).powZn(t0.duplicate().negate())).getImmutable();
        Element kt=parent.kt.mul(pp.g.powZn(t0)).getImmutable();
        Element[] suffix=new Element[D+1];
        for (int i=ell+2;i<=D;i++) suffix[i]=parent.kSuffix[i].mul(pp.u[i].powZn(t0)).getImmutable();
        return new SecretKey(childIds,parent.y.clone(),kh,kt,suffix);
    }

    /** Decrypt to the pairing encoding, then recover the bounded integer via lookup. */
    private Element decryptEncoding(Ciphertext ct,SecretKey sk) {
        if (ct.ids.length!=sk.ids.length) throw new IllegalArgumentException("identity depth mismatch");
        for (int i=0;i<ct.ids.length;i++) if (!ct.ids[i].isEqual(sk.ids[i]))
            throw new IllegalArgumentException("identity mismatch");
        Element product=pairing.getGT().newOneElement();
        for (int i=0;i<sk.y.length;i++) product=product.mul(ct.cx[i].powZn(sk.y[i]));
        Element a2=pairing.pairing(ct.cr,sk.kh);
        Element a3=pairing.pairing(ct.cu,sk.kt);
        return product.div(a2).div(a3).getImmutable();
    }

    private long decrypt(Ciphertext ct,SecretKey sk,Map<String,Integer> lookup) {
        Integer m=lookup.get(decryptEncoding(ct,sk).toString());
        if (m==null) throw new IllegalStateException("inner product is outside lookup range");
        return m;
    }

    private Map<String,Integer> precomputeLookup(Element egg) {
        Map<String,Integer> result=new HashMap<>(MAX_INNER_PRODUCT*2);
        Element current=pairing.getGT().newOneElement();
        for (int m=0;m<=MAX_INNER_PRODUCT;m++) {
            result.put(current.toString(),m);
            current=current.mul(egg);
        }
        return result;
    }

    private double medianMs(Runnable task) {
        for (int i=0;i<WARMUPS;i++) task.run();
        long[] ns=new long[SAMPLES];
        for (int i=0;i<SAMPLES;i++) { long t=System.nanoTime(); task.run(); ns[i]=System.nanoTime()-t; }
        Arrays.sort(ns);
        return ns[ns.length/2]/1_000_000.0;
    }

    private void run(String outputFile) throws Exception {
        Path csv=Paths.get(outputFile);
        if (csv.getParent()!=null) Files.createDirectories(csv.getParent());
        // Warm up the one-shot lookup-table construction before recording it.
        precomputeLookup(setup(1).pp.egg);
        try (BufferedWriter out=Files.newBufferedWriter(csv,StandardCharsets.UTF_8)) {
            out.write("n,d,level,setup_core_ms,precompute_0_10000_ms,setup_total_ms,encryption_ms,keygen_ms,delegate_ms,decryption_ms,inner_product,direct_ok,delegated_ok\n");
            for (int n:DIMENSIONS) {
                final int dim=n;
                double setupCoreMs=medianMs(()->setup(dim));
                SetupResult st=setup(n);
                long preT=System.nanoTime();
                Map<String,Integer> lookup=precomputeLookup(st.pp.egg);
                double precomputeMs=(System.nanoTime()-preT)/1_000_000.0;
                Element[] ids=new Element[LEVEL];
                for (int i=0;i<LEVEL;i++) ids[i]=pairing.getZr().newElement(100+i).getImmutable();
                Element childId=pairing.getZr().newElement(999).getImmutable();
                Element[] x=new Element[n],y=new Element[n]; long dot=0;
                for (int i=0;i<n;i++) {
                    int xv=1+i%5,yv=1+(i+2)%5;
                    x[i]=pairing.getZr().newElement(xv).getImmutable();
                    y[i]=pairing.getZr().newElement(yv).getImmutable(); dot+=(long)xv*yv;
                }
                if (dot>MAX_INNER_PRODUCT) throw new IllegalStateException("increase MAX_INNER_PRODUCT");
                Ciphertext ct=encrypt(st.pp,ids,x);
                SecretKey sk=keyGen(st,ids,y);
                SecretKey childSk=delegate(st.pp,sk,childId);
                Element[] childIds=Arrays.copyOf(ids,LEVEL+1); childIds[LEVEL]=childId;
                Ciphertext childCt=encrypt(st.pp,childIds,x);

                double encMs=medianMs(()->encrypt(st.pp,ids,x));
                double keyMs=medianMs(()->keyGen(st,ids,y));
                double delegateMs=medianMs(()->delegate(st.pp,sk,childId));
                double decMs=medianMs(()->decrypt(ct,sk,lookup));
                long direct=decrypt(ct,sk,lookup), delegated=decrypt(childCt,childSk,lookup);
                boolean directOk=direct==dot, delegatedOk=delegated==dot;
                double setupTotal=setupCoreMs+precomputeMs;
                out.write(String.format(Locale.US,"%d,%d,%d,%.6f,%.6f,%.6f,%.6f,%.6f,%.6f,%.6f,%d,%s,%s%n",
                        n,D,LEVEL,setupCoreMs,precomputeMs,setupTotal,encMs,keyMs,delegateMs,decMs,dot,directOk,delegatedOk));
                out.flush();
                System.out.printf(Locale.US,
                        "n=%d d=%d level=%d Setup(core)=%.6f ms precompute=%.6f ms Enc=%.6f ms KeyGen=%.6f ms Delegate=%.6f ms Dec=%.6f ms dot=%d direct=%s delegated=%s%n",
                        n,D,LEVEL,setupCoreMs,precomputeMs,encMs,keyMs,delegateMs,decMs,dot,directOk,delegatedOk);
            }
        }
        System.out.println("CSV="+csv.toAbsolutePath());
        System.out.printf("JPBC=%s; lookup range=0..%d; warmups=%d; samples=%d%n",pairingFile,MAX_INNER_PRODUCT,WARMUPS,SAMPLES);
    }

    public static void main(String[] args) throws Exception {
        String params=args.length>0?args[0]:"storeFile/Song_File/a.properties";
        String csv=args.length>1?args[1]:"song-hib-ipfe-results.csv";
        new Song(params).run(csv);
    }
}
