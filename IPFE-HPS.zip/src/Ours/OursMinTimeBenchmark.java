package Ours;

import it.unisa.dia.gas.jpbc.Element;
import it.unisa.dia.gas.jpbc.ElementPowPreProcessing;
import it.unisa.dia.gas.jpbc.Pairing;
import it.unisa.dia.gas.plaf.jpbc.pairing.PairingFactory;

import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;

/**
 * IB-IPFE-HPS core benchmark, following the normal Setup/KeyGen/Encap/Decap
 * equations in the attached paper and the layout of the project's Ours code.
 *
 * The available project parameter file is JPBC Type A (prime-order symmetric).
 * The paper's security construction uses composite-order groups and a Gp3
 * subgroup. Here X3 is set to the identity, so this is a functional core
 * benchmark only; it does not instantiate the paper's composite-order security.
 */
public final class OursMinTimeBenchmark {
    private static final int[] DIMENSIONS = {10, 15, 20, 25,30};
    private static final int WARMUPS = 5;
    private static final int SAMPLES = 25;
    private static final String IDENTITY = "Wangjing";

    private final Pairing pairing;
    private final String pairingFile;

    private OursMinTimeBenchmark(String pairingFile) {
        this.pairingFile = pairingFile;
        PairingFactory.getInstance().setUsePBCWhenPossible(true);
        this.pairing = PairingFactory.getPairing(pairingFile);
    }

    private static final class PublicParams {
        final Element g, u, h, eGG, eAlpha, eEta, uidh;
        final ElementPowPreProcessing gPow, uidhPow;
        PublicParams(Element g, Element u, Element h, Element eGG,
                     Element eAlpha, Element eEta, Element uidh,
                     ElementPowPreProcessing gPow, ElementPowPreProcessing uidhPow) {
            this.g=g; this.u=u; this.h=h; this.eGG=eGG;
            this.eAlpha=eAlpha; this.eEta=eEta; this.uidh=uidh;
            this.gPow=gPow; this.uidhPow=uidhPow;
        }
    }

    private static final class MasterKey {
        final Element alpha, eta, x3;
        MasterKey(Element alpha, Element eta, Element x3) {
            this.alpha=alpha; this.eta=eta; this.x3=x3;
        }
    }

    private static final class SetupResult {
        final PublicParams pp;
        final MasterKey msk;
        SetupResult(PublicParams pp, MasterKey msk) { this.pp=pp; this.msk=msk; }
    }

    private static final class PrivateKey {
        final Element[] y, d1;
        final Element d2, d3;
        PrivateKey(Element[] y, Element[] d1, Element d2, Element d3) {
            this.y=y; this.d1=d1; this.d2=d2; this.d3=d3;
        }
    }

    private static final class Ciphertext {
        final Element c1, c2, c3;
        final Element[] cx;
        final Element[] encapsulatedVector;
        Ciphertext(Element c1, Element c2, Element c3, Element[] cx,
                   Element[] encapsulatedVector) {
            this.c1=c1; this.c2=c2; this.c3=c3; this.cx=cx;
            this.encapsulatedVector=encapsulatedVector;
        }
    }

    private Element randomScalar() {
        return pairing.getZr().newRandomElement().getImmutable();
    }

    private Element gtOne() {
        return pairing.getGT().newOneElement().getImmutable();
    }

    private Element identityScalar(String id) {
        byte[] bytes=id.getBytes(StandardCharsets.UTF_8);
        return pairing.getZr().newElementFromHash(bytes,0,bytes.length).getImmutable();
    }

    /** Setup(1^k,n): master key (alpha,eta,X3), public pairing bases. */
    private SetupResult setup() {
        Element g=pairing.getG1().newRandomElement().getImmutable();
        Element u=pairing.getG1().newRandomElement().getImmutable();
        Element h=pairing.getG1().newRandomElement().getImmutable();
        Element alpha=randomScalar();
        Element eta=randomScalar();

        // A prime-order JPBC Type A group has no distinct Gp3 subgroup.
        // Keep the X3 terms neutral rather than using a random element as if it
        // belonged to Gp3 (which would break correctness).
        Element x3=pairing.getG1().newOneElement().getImmutable();
        Element eGG=pairing.pairing(g,g).getImmutable();
        Element eAlpha=eGG.powZn(alpha).getImmutable();
        Element eEta=eGG.powZn(eta).getImmutable();
        Element id=identityScalar(IDENTITY);
        Element uidh=u.powZn(id).mul(h).getImmutable();

        return new SetupResult(
                new PublicParams(g,u,h,eGG,eAlpha,eEta,uidh,
                        g.getElementPowPreProcessing(),uidh.getElementPowPreProcessing()),
                new MasterKey(alpha,eta,x3));
    }

    /** KeyGen(msk,id,y), with additive random shares whose sum is r. */
    private PrivateKey keyGen(SetupResult setup, Element[] y) {
        PublicParams pp=setup.pp;
        MasterKey msk=setup.msk;
        int n=y.length;
        Element r=randomScalar();
        Element t=randomScalar();

        Element[] rShares=new Element[n];
        Element partial=pairing.getZr().newZeroElement();
        for (int i=0;i<n-1;i++) {
            rShares[i]=randomScalar();
            partial=partial.add(rShares[i]);
        }
        rShares[n-1]=r.duplicate().sub(partial).getImmutable();

        Element alphaMinusEtaT=msk.alpha.duplicate()
                .sub(msk.eta.duplicate().mul(t)).getImmutable();
        Element[] d1=new Element[n];
        for (int i=0;i<n;i++) {
            Element exponent=alphaMinusEtaT.duplicate().mul(y[i]);
            // X3 is the identity in this Type-A functional-core benchmark.
            // Therefore X3^rho is always the identity; omit this exponentiation.
            d1[i]=pp.gPow.powZn(exponent)
                    .mul(pp.uidhPow.powZn(rShares[i]))
                    .getImmutable();
        }
        // Same identity-element simplification for the d2 mask.
        Element d2=pp.gPow.powZn(r.duplicate().negate()).getImmutable();
        return new PrivateKey(y.clone(),d1,d2,t);
    }

    /** Valid Encap(id): c1,c2,c3,cx[1..n], and the encapsulated vector x. */
    private Ciphertext encapsulate(SetupResult setup, Element[] x) {
        PublicParams pp=setup.pp;
        Element z=randomScalar();
        Element c1=pp.g.powZn(z).getImmutable();
        Element c2=pp.uidh.powZn(z).getImmutable();
        Element c3=pp.eEta.powZn(z).getImmutable();
        Element minusAlphaZ=setup.msk.alpha.duplicate().mul(z).negate().getImmutable();
        Element[] cx=new Element[x.length];
        for (int i=0;i<x.length;i++) {
            cx[i]=pp.eGG.powZn(x[i])
                    .mul(pp.eGG.powZn(minusAlphaZ)).getImmutable();
        }
        return new Ciphertext(c1,c2,c3,cx,x.clone());
    }

    private long decapsulate(Ciphertext ct, PrivateKey sk, SetupResult setup,
                             long maxDot) {
        Element productD1=pairing.getG1().newOneElement().getImmutable();
        for (Element d:sk.d1) productD1=productD1.mul(d);
        Element result=pairing.pairing(ct.c1,productD1)
                .mul(pairing.pairing(ct.c2,sk.d2));
        for (int i=0;i<sk.y.length;i++) {
            Element term=ct.c3.powZn(sk.d3).mul(ct.cx[i]);
            result=result.mul(term.powZn(sk.y[i]));
        }
        result=result.getImmutable();

        Element candidate=gtOne();
        for (long k=0;k<=maxDot;k++) {
            if (candidate.isEqual(result)) return k;
            candidate=candidate.mul(setup.pp.eGG);
        }
        throw new IllegalStateException("Bounded discrete log failed; verify key/ciphertext equations");
    }

    private double measure(Runnable operation) {
        for (int i=0;i<WARMUPS;i++) operation.run();
        List<Long> ns=new ArrayList<>();
        for (int i=0;i<SAMPLES;i++) {
            long start=System.nanoTime();
            operation.run();
            ns.add(System.nanoTime()-start);
        }
        long[] sorted=new long[ns.size()];
        for (int i=0;i<sorted.length;i++) sorted[i]=ns.get(i);
        Arrays.sort(sorted);
        return sorted[0]/1_000_000.0;
    }

    private void run(String outputFile) throws IOException {
        Path output=Paths.get(outputFile);
        if (output.getParent()!=null) Files.createDirectories(output.getParent());
        try (BufferedWriter writer=Files.newBufferedWriter(output,StandardCharsets.UTF_8)) {
            writer.write("n,setup_min_ms,encryption_min_ms,keygen_min_ms,decryption_min_ms,expected_dot,recovered_dot,correct\n");
            for (int n:DIMENSIONS) {
                final int dim=n;
                double setupMs=measure(()->setup());
                SetupResult current=setup();
                Element[] x=new Element[n], y=new Element[n];
                long expected=0;
                for (int i=0;i<n;i++) {
                    int xi=1+(i%5), yi=1+((i+2)%5);
                    x[i]=pairing.getZr().newElement(xi).getImmutable();
                    y[i]=pairing.getZr().newElement(yi).getImmutable();
                    expected+=(long)xi*yi;
                }
                final long maxDot=expected;
                Ciphertext ct=encapsulate(current,x);
                PrivateKey sk=keyGen(current,y);
                double encMs=measure(()->encapsulate(current,x));
                double keyMs=measure(()->keyGen(current,y));
                double decMs=measure(()->{
                    long value=decapsulate(ct,sk,current,maxDot);
                    if (value!=maxDot) throw new IllegalStateException("Incorrect inner product");
                });
                long recovered=decapsulate(ct,sk,current,maxDot);
                boolean correct=recovered==expected;
                writer.write(String.format(Locale.US,
                        "%d,%.6f,%.6f,%.6f,%.6f,%d,%d,%s%n",
                        dim,setupMs,encMs,keyMs,decMs,expected,recovered,correct));
                writer.flush();
                System.out.printf(Locale.US,
                        "n=%d Setup(min)=%.6f ms Encryption(min)=%.6f ms KeyGen(min)=%.6f ms Decryption(min)=%.6f ms dot=%d/%d correct=%s%n",
                        n,setupMs,encMs,keyMs,decMs,expected,recovered,correct);
            }
        }
        System.out.println("CSV written to: "+output.toAbsolutePath());
        System.out.printf("Pairing=%s; warmups=%d; samples=%d; identity=%s%n",
                pairingFile,WARMUPS,SAMPLES,IDENTITY);
    }

    public static void main(String[] args) throws Exception {
        String pairingFile=args.length>0?args[0]:"storeFile/Ours_File/a.properties";
        String output=args.length>1?args[1]:"ib-ipfe-hps-optimized-results.csv";
        new OursMinTimeBenchmark(pairingFile).run(output);
    }
}

