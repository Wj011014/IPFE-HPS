package Ours;

import it.unisa.dia.gas.jpbc.Element;
import it.unisa.dia.gas.jpbc.Pairing;
import it.unisa.dia.gas.plaf.jpbc.pairing.PairingFactory;

import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;

/**
 * Benchmark for the Setup, KeyGen, Enc, and Dec equations in the supplied
 * construction images. Uses the existing project's JPBC Type A parameters.
 */
public final class ProxyIPFEBenchmark {
    private static final int[] DIMENSIONS = {10, 15, 20, 25};
    private static final int WARMUPS = 5;
    private static final int SAMPLES = 25;
    private static final int ID_VALUE = 2;

    private final Pairing pairing;
    private final String pairingFile;

    private ProxyIPFEBenchmark(String pairingFile) {
        this.pairingFile=pairingFile;
        PairingFactory.getInstance().setUsePBCWhenPossible(true);
        this.pairing=PairingFactory.getPairing(pairingFile);
    }

    private static final class PublicParams {
        final Element g, h, g1, eGG, eGH;
        PublicParams(Element g, Element h, Element g1, Element eGG, Element eGH) {
            this.g=g; this.h=h; this.g1=g1; this.eGG=eGG; this.eGH=eGH;
        }
    }
    private static final class SetupResult {
        final PublicParams pp;
        final Element alpha;
        SetupResult(PublicParams pp, Element alpha) { this.pp=pp; this.alpha=alpha; }
    }
    private static final class PrivateKey {
        final Element id, r;
        final Element[] y, hId;
        PrivateKey(Element id, Element r, Element[] y, Element[] hId) {
            this.id=id; this.r=r; this.y=y; this.hId=hId;
        }
    }
    private static final class Ciphertext {
        final Element id, c1, c2;
        final Element[] cx, x;
        Ciphertext(Element id, Element c1, Element c2, Element[] cx, Element[] x) {
            this.id=id; this.c1=c1; this.c2=c2; this.cx=cx; this.x=x;
        }
    }

    private Element randomScalar() { return pairing.getZr().newRandomElement().getImmutable(); }
    private Element gtOne() { return pairing.getGT().newOneElement().getImmutable(); }

    /** (msk, Params) <- Setup(1^k,n). */
    private SetupResult setup() {
        Element g=pairing.getG1().newRandomElement().getImmutable();
        Element h=pairing.getG1().newRandomElement().getImmutable();
        Element alpha=randomScalar();
        Element g1=g.powZn(alpha).getImmutable();
        Element eGG=pairing.pairing(g,g).getImmutable();
        Element eGH=pairing.pairing(g,h).getImmutable();
        return new SetupResult(new PublicParams(g,h,g1,eGG,eGH),alpha);
    }

    /** sk_{id,y}: r_id and componentwise h_id=(h g^{-r_id})^{y/(alpha-id)}. */
    private PrivateKey keyGen(SetupResult st, Element id, Element[] y) {
        Element denom=st.alpha.duplicate().sub(id).getImmutable();
        if (denom.isZero()) throw new IllegalArgumentException("id must differ from alpha");
        Element r=randomScalar();
        Element hBase=st.pp.h.mul(st.pp.g.powZn(r.duplicate().negate())).getImmutable();
        Element denomInv=denom.invert().getImmutable();
        Element[] hId=new Element[y.length];
        for (int i=0;i<y.length;i++) {
            Element exponent=y[i].duplicate().mul(denomInv).getImmutable();
            hId[i]=hBase.powZn(exponent).getImmutable();
        }
        return new PrivateKey(id,r,y.clone(),hId);
    }

    /** CT_{id,x} <- Enc(id,x). */
    private Ciphertext encrypt(SetupResult st, Element id, Element[] x) {
        Element s=randomScalar();
        Element c1=st.pp.g1.powZn(s)
                .mul(st.pp.g.powZn(s.duplicate().mul(id).negate())).getImmutable();
        Element c2=st.pp.eGG.powZn(s).getImmutable();
        Element[] cx=new Element[x.length];
        Element negS=s.duplicate().negate().getImmutable();
        for (int i=0;i<x.length;i++) {
            cx[i]=st.pp.eGH.powZn(negS)
                    .mul(st.pp.eGG.powZn(x[i])).getImmutable();
        }
        return new Ciphertext(id,c1,c2,cx,x.clone());
    }

    /** Dec: returns the bounded discrete log of e(g,g)^{<x,y>}. */
    private long decrypt(SetupResult st, Ciphertext ct, PrivateKey sk, long maxInnerProduct) {
        if (!ct.id.isEqual(sk.id)) throw new IllegalArgumentException("identity mismatch");
        Element cxProduct=gtOne();
        Element hIdProduct=pairing.getG1().newOneElement().getImmutable();
        Element ySum=pairing.getZr().newZeroElement();
        for (int i=0;i<sk.y.length;i++) {
            cxProduct=cxProduct.mul(ct.cx[i].powZn(sk.y[i]));
            hIdProduct=hIdProduct.mul(sk.hId[i]);
            ySum=ySum.add(sk.y[i]);
        }
        Element rIdY=sk.r.duplicate().mul(ySum).getImmutable();
        Element result=cxProduct
                .mul(pairing.pairing(ct.c1,hIdProduct))
                .mul(ct.c2.powZn(rIdY)).getImmutable();

        Element candidate=gtOne();
        for (long k=0;k<=maxInnerProduct;k++) {
            if (candidate.isEqual(result)) return k;
            candidate=candidate.mul(st.pp.eGG);
        }
        throw new IllegalStateException("Bounded discrete log failed; check scheme equations");
    }

    private double medianMs(Runnable algorithm) {
        for (int i=0;i<WARMUPS;i++) algorithm.run();
        List<Long> times=new ArrayList<>();
        for (int i=0;i<SAMPLES;i++) {
            long t0=System.nanoTime(); algorithm.run();
            times.add(System.nanoTime()-t0);
        }
        long[] sorted=new long[times.size()];
        for (int i=0;i<sorted.length;i++) sorted[i]=times.get(i);
        Arrays.sort(sorted);
        return sorted[sorted.length/2]/1_000_000.0;
    }

    private void run(String csvFile) throws IOException {
        Path path=Paths.get(csvFile);
        if (path.getParent()!=null) Files.createDirectories(path.getParent());
        try (BufferedWriter out=Files.newBufferedWriter(path,StandardCharsets.UTF_8)) {
            out.write("n,setup_ms,encryption_ms,keygen_ms,decryption_ms,expected,recovered,correct\n");
            for (int n:DIMENSIONS) {
                double setupMs=medianMs(this::setup);
                SetupResult st=setup();
                Element id=pairing.getZr().newElement(ID_VALUE).getImmutable();
                Element[] x=new Element[n], y=new Element[n];
                long expected=0;
                for (int i=0;i<n;i++) {
                    int xv=1+(i%5), yv=1+((i+2)%5);
                    x[i]=pairing.getZr().newElement(xv).getImmutable();
                    y[i]=pairing.getZr().newElement(yv).getImmutable();
                    expected+=(long)xv*yv;
                }
                final long maxValue=expected;
                Ciphertext ct=encrypt(st,id,x);
                PrivateKey sk=keyGen(st,id,y);
                double encMs=medianMs(()->encrypt(st,id,x));
                double keyMs=medianMs(()->keyGen(st,id,y));
                double decMs=medianMs(()->{
                    long value=decrypt(st,ct,sk,maxValue);
                    if (value!=maxValue) throw new IllegalStateException("incorrect inner product");
                });
                long recovered=decrypt(st,ct,sk,maxValue);
                boolean correct=recovered==expected;
                out.write(String.format(Locale.US,"%d,%.6f,%.6f,%.6f,%.6f,%d,%d,%s%n",
                        n,setupMs,encMs,keyMs,decMs,expected,recovered,correct));
                out.flush();
                System.out.printf(Locale.US,
                        "n=%d Setup=%.6f ms Encryption=%.6f ms KeyGen=%.6f ms Decryption=%.6f ms dot=%d/%d correct=%s%n",
                        n,setupMs,encMs,keyMs,decMs,expected,recovered,correct);
            }
        }
        System.out.println("CSV written to: "+path.toAbsolutePath());
        System.out.printf("JPBC parameters=%s; warmups=%d; samples=%d; ID=%d%n",
                pairingFile,WARMUPS,SAMPLES,ID_VALUE);
    }

    public static void main(String[] args) throws Exception {
        String pairingFile=args.length>0?args[0]:"storeFile/Ours_File/a.properties";
        String csvFile=args.length>1?args[1]:"proxy-ipfe-results.csv";
        new ProxyIPFEBenchmark(pairingFile).run(csvFile);
    }
}
