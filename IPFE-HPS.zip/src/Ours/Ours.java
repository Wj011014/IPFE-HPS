package Ours;

import it.unisa.dia.gas.jpbc.*;
import it.unisa.dia.gas.plaf.jpbc.pairing.PairingFactory;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.UnsupportedEncodingException;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class Ours {

    static Pairing pairing;
    private static Element g, u, h, eAlpha,eeta,uidh;
    private static Element galpha,geta,X3; // Master secret key
    private static String ID = new String();

    // Setup Algorithm
    public static void setup() {
        pairing = PairingFactory.getPairing("./storeFile/Ours_File/a.properties");
        PairingFactory.getInstance().setUsePBCWhenPossible(true);
        // Generate random elements
        SecureRandom random = new SecureRandom();
        g = pairing.getG1().newRandomElement().getImmutable();
        u = pairing.getG1().newRandomElement().getImmutable();
        h = pairing.getG1().newRandomElement().getImmutable();
        X3 = pairing.getG2().newRandomElement().getImmutable();
        Element alpha = pairing.getZr().newRandomElement().getImmutable();
        Element eta = pairing.getZr().newRandomElement().getImmutable();
        galpha = g.powZn(alpha).getImmutable();
        geta = g.powZn(eta).getImmutable();
        // Calculate eAlpha = e(g, g)^alpha
        eAlpha = pairing.pairing(g, galpha).getImmutable();
        eeta = pairing.pairing(g, geta).getImmutable();
    }

    // Key Generation Algorithm
// Key Generation Algorithm
    public static Object[] keyGen(int size1, Element[] yVector) {
        Element r = pairing.getZr().newRandomElement().getImmutable();
        Element t = pairing.getZr().newRandomElement().getImmutable();
        Element rho = pairing.getZr().newRandomElement().getImmutable();
        Element rho1 = pairing.getZr().newRandomElement().getImmutable();


        // Compute K
        Element d2 = g.powZn(r.invert()).mul(X3.powZn(rho1)).getImmutable();


        // Generate keys for each attribute
        Element[] d1 = new Element[size1];
        for (int i = 0; i < size1; i++)
            d1[i] = galpha.powZn(yVector[i]).mul(geta.powZn(t.invert().mulZn(yVector[i]))).mul(uidh).powZn(r).mul(X3.powZn(rho)).getImmutable();


        // Return K0, K1, and attributeKeys
        return new Object[]{d1, d2, t};
    }


    public static Object[] encrypt(Element[] xVector) {
        Element z = pairing.getZr().newRandomElement().getImmutable();
        Element c1  = g.powZn(z).getImmutable();
        Element c2 = u.powZn(pairing.getZr().newElementFromBytes(ID.getBytes()).mul(z)).mul(h.powZn(z)).getImmutable();
        Element c3 = pairing.pairing(geta,g).powZn(z).getImmutable();

            Element[] Cx = new Element[xVector.length];
            for (int i = 0; i < xVector.length; i++) {
                Cx[i] = pairing.pairing(g,g).powZn(xVector[i]).mulZn(pairing.pairing(galpha,g).powZn(z.invert())).getImmutable();
            }


            // Return ciphertext
            return new Object[]{c1, c2,c3, Cx};


    }




    public static String decrypt(Object[] ciphertext, Object[] privateKey,  Element[] yVector) throws UnsupportedEncodingException {

            // Parse ciphertext components
            Element c1 = (Element) ciphertext[0]; // C1
            Element c2 = (Element) ciphertext[1];
            Element c3 = (Element) ciphertext[2];
            Element[] Cx = (Element[]) ciphertext[3]; // Array of C_i (1D)


            // Parse private key components
            Element[] d1 = (Element[]) privateKey[0]; // K
            Element d2 = (Element) privateKey[1]; // K0
            Element d3 = (Element) privateKey[2]; // Array of K_{i} (1D)

            // Step 1: Compute numerator: prod(C_i^y_i)
            Element c3d3 = c3.powZn(d3).getImmutable();
            Element cxy = pairing.getGT().newOneElement().getImmutable();
            for (int i = 0; i < Cx.length; i++) {
                cxy = cxy.mul(Cx[i].mul(c3d3)).powZn(yVector[i]).getImmutable();
            }

            Element c2d2 = pairing.pairing(c2,d2).getImmutable();

            Element d1i = pairing.getG1().newOneElement().getImmutable();
            for (int i = 0; i < Cx.length; i++)
                d1i = d1i.mul(d1[i]).getImmutable();
            Element c1d1 = pairing.pairing(c1,d1i).getImmutable();
            Element finalResult = c1d1.mulZn(c2d2.mulZn(c3d3.mulZn(cxy))).getImmutable();
            // Convert decrypted element to plaintext string
            byte[] decryptedBytes = finalResult.toBytes();
            return new String(decryptedBytes, "UTF-8");

    }

    public static String[] generateArray(String[] baseArray, int targetSize) {
        List<String> result = new ArrayList<>();
        int baseLength = baseArray.length;

        // 循环填充
        while (result.size() < targetSize) {
            for (String item : baseArray) {
                if (result.size() < targetSize) {
                    result.add(item);
                } else {
                    break;
                }
            }
        }

        // 转为数组返回
        return result.toArray(new String[0]);
    }

    public static long calculateStorageCost(Object[] objectArray) {
        long totalBits = 0;

        for (Object obj : objectArray) {
            if (obj instanceof Element) {
                // 将 Element 转为字节数组
                byte[] bytes = ((Element) obj).toBytes();
                totalBits += bytes.length * 8; // 字节转换为比特
            } else {
                System.out.println("Warning: Non-Element object encountered, skipping...");
            }
        }

        return totalBits;
    }
    public static void main(String[] args) throws UnsupportedEncodingException {
        // Step 1: Setup phase
        ID = "Wangjing";


            int size1 = 30;
            long start = System.currentTimeMillis();
            setup();

        long end = System.currentTimeMillis();
            System.out.print("Setup运行时间为");
            System.out.println(end - start);
        uidh = u.powZn(PairingFactory.getPairing("./storeFile/Ours_File/a.properties").getZr().newElementFromBytes(ID.getBytes()).getImmutable()).mul(h);

        Element[] xVector = new Element[size1];
            Element[] yVector = new Element[size1];
            // Initialize the vectors with random elements
            for (int i = 0; i < size1; i++) {
                xVector[i] = pairing.getZr().newRandomElement().getImmutable(); // Random x_i
                yVector[i] = pairing.getZr().newRandomElement().getImmutable(); // Random y_i
            }


            long start1 = System.currentTimeMillis();
            Object[] privateKeyData = keyGen(size1, yVector);
            long end1 = System.currentTimeMillis();
            System.out.print("KeyGen运行时间为");
            System.out.println(end1 - start1);
            // 打印结果


            // Step 4: Encryption phase
            String message = "Confidential Data";
            long start2 = System.currentTimeMillis();
            Object[] ciphertext = encrypt(xVector);
            long end2 = System.currentTimeMillis();
            System.out.print("Encryption运行时间为");
            System.out.println(end2 - start2);

            // Step 5: Decryption phase
            long start3 = System.currentTimeMillis();
            String decryptedMessage = decrypt(ciphertext, privateKeyData, yVector);
            //System.out.println("Final result e(g, g)^{<x, y>}: " + decryptedMessage);
            long end3 = System.currentTimeMillis();
            System.out.print("Decryption运行时间为");
            System.out.println(end3 - start3);
        }
    }

