package Belel;

import it.unisa.dia.gas.jpbc.Element;
import it.unisa.dia.gas.jpbc.Pairing;
import it.unisa.dia.gas.plaf.jpbc.pairing.PairingFactory;
import it.unisa.dia.gas.plaf.jpbc.pairing.a.TypeACurveGenerator;

import java.io.*;
import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Base64;
import java.util.Properties;
import java.util.Random;

import static java.lang.System.out;

public class Belel {

    public static void setup(String pairingFile, String paramsFile, String mskFile, String vectorFile, int n, int d) {
        Pairing bp = PairingFactory.getPairing(pairingFile);
        Properties params = new Properties();
        Properties msk = new Properties();
        Element g = bp.getG1().newRandomElement().getImmutable();
        Element gi = bp.getG1().newRandomElement().getImmutable();
        Element alpha = bp.getZr().newRandomElement().getImmutable();

        Element g1 = g.powZn(alpha);
        Element g1i = gi.powZn(alpha);
        Element u = bp.pairing(g,gi).getImmutable();
        params.setProperty("g", g.toString());
        params.setProperty("g1", g1.toString());
        params.setProperty("gi", gi.toString());
        params.setProperty("g1i", g1i.toString());
        params.setProperty("u", u.toString());
        Element[] h = new Element[d + 1];
        Element[] h1 = new Element[d + 1];
        Element[] delta = new Element[d + 1];
        Element[] gamma = new Element[n + 1];
        Element[] g0 = new Element[n+1];
        Element[] w = new Element[n+1];

        for (int i = 1;i<=n;i++)
        {

            gamma[i] = bp.getZr().newRandomElement().getImmutable();

        }
        for (int i = 1; i<=d; i++)
        {
            delta[i] = bp.getZr().newRandomElement().getImmutable();
            h[i] = g.powZn(delta[i]).getImmutable();
            h1[i] = gi.powZn(delta[i]).getImmutable();
            params.setProperty("h" + i, h[i].toString());
            params.setProperty("hi" + i, h[i].toString());
        }

        Element b = bp.getZr().newRandomElement().getImmutable();

        for (int i = 1; i <=n; i++)
        {
            g0[i] = g1i.powZn(b.mulZn(gamma[i])).getImmutable();
            msk.setProperty("g0"+i, String.valueOf(g0[i].toBytes()));
        }
        Element v = u.powZn(alpha.mulZn(b)).getImmutable();

        for (int i = 1; i <=n; i++)
        {
            w[i] = v.powZn(gamma[i]).getImmutable();
            params.setProperty("w"+i, w[i].toString());
        }

        storePropToFile(params, paramsFile);
        storePropToFile(msk, mskFile);
        out.println("Setup phase completed.");
    }

    public static void Encryption(String pairingFile, String paramsFile, String vectorFile, String CTFile, String randomFile, String[] ID, int n, double[] x, int d, int l) throws NoSuchAlgorithmException {
        Pairing bp = PairingFactory.getPairing(pairingFile);
        Properties params = loadPropFromFile(paramsFile);
        Properties random = loadPropFromFile(randomFile);
        Element g = bp.getG1().newElementFromBytes(params.getProperty("g").getBytes()).getImmutable();
        Element g1 = bp.getG1().newElementFromBytes(params.getProperty("g1").getBytes()).getImmutable();
        Element u = bp.getG1().newElementFromBytes(params.getProperty("u").getBytes()).getImmutable();
        Element[] w = new Element[n+1];
        Element[] h = new Element[d+1];
        Element s = bp.getZr().newRandomElement().getImmutable();

        for (int i = 1; i <=d; i++) {
            h[i] = bp.getG1().newElementFromBytes(params.getProperty("h" + i).getBytes()).getImmutable();
        }
        for (int i = 1; i <=n ;i++ )
            w[i]=bp.getG1().newElementFromBytes(params.getProperty("w" + i).getBytes()).getImmutable();

        Element[] xi = new Element[n+1];
        Element[] Ei = new Element[n+1];
        for (int i = 1; i <= n; i++) {
            xi[i] = bp.getZr().newElementFromBytes(String.valueOf(x[i-1]).getBytes()).getImmutable();
            random.setProperty("x"+i, String.valueOf(x[i-1]));
            Ei[i] = u.powZn(xi[i]).mul(w[i].powZn(s)).getImmutable();
        }

        Element C0 = g.powZn(s).getImmutable();
        Element[] Ck = new Element[l+1];

        for (int i = 1; i <= l; i++)
        {
            Ck[i] = g1.powZn(bp.getZr().newElementFromBytes(ID[i-1].getBytes(StandardCharsets.UTF_8)).getImmutable().mulZn(s)).mul(h[i].powZn(s)).getImmutable();
        }


        Properties CT = new Properties();
        for (int i = 1; i <= n; i++) {
            CT.setProperty("E" + i, Ei[i].toString());
        }
        for (int i = 1; i <= l; i++) {
            CT.setProperty("Ck" + i, Ck[i].toString());
        }
        CT.setProperty("C0", C0.toString());

        storePropToFile(CT, CTFile);


        random.setProperty("s", s.toString());
        storePropToFile(random, randomFile);

        out.println("Encryption phase completed.");
    }

    public static void KGen(String pairingFile, String paramsFile, String mskFile, String vectorFile, String skFile, String randomFile, double[] y, int n, int d, String[] ID, int l) throws NoSuchAlgorithmException {
        Pairing bp = PairingFactory.getPairing(pairingFile);
        Properties params = loadPropFromFile(paramsFile);
        Properties vPro = loadPropFromFile(vectorFile);
        Properties sk = loadPropFromFile(skFile);
        Properties msk = loadPropFromFile(mskFile);
        Properties random = loadPropFromFile(randomFile);
        Properties mskProp = loadPropFromFile(mskFile);

        Element gi = bp.getG1().newElementFromBytes(params.getProperty("gi").getBytes()).getImmutable();
        Element g1i = bp.getG1().newElementFromBytes(params.getProperty("g1i").getBytes()).getImmutable();

        Element[] r = new Element[l+1];
        Element[] hi = new Element[l+1];
        Element[] g0 = new Element[n+1];
        for (int i = 1; i <=n; i++)
            g0[i] = bp.getG1().newElementFromBytes(msk.getProperty("g0"+i).getBytes()).getImmutable();
        for (int i = 1; i <= l; i++)
        {
            hi[i] = bp.getZr().newElementFromBytes(params.getProperty("hi"+i).getBytes()).getImmutable();
            r[i] = bp.getZr().newRandomElement().getImmutable();
            random.setProperty("r"+i, r[i].toString());
        }
        Element[] D = new Element[l+1];
        Element[] g0y = new Element[n+1];
        Element[] g1h = new Element[l+1];
        Element[] yi = new Element[n+1];
        Element D0 = PairingFactory.getPairing(pairingFile).getG1().newOneElement().getImmutable();
        for (int i = 1; i <= l; i++)
        {
            D[i] = gi.powZn(r[i]).getImmutable();
            sk.setProperty("Di"+i, D[i].toString());
        }
        for (int i = 1; i <=n; i++)
        {
            yi[i] = bp.getZr().newElementFromBytes(String.valueOf(y[i-1]).getBytes()).getImmutable();
            g0y[i] = g0[i].powZn(yi[i]).getImmutable();
            D0 = D0.mulZn(g0y[i]).getImmutable();
            vPro.setProperty("y"+i,yi[i].toString());
        }
        for (int i = 1; i <= l; i++)
        {
            g1h[i] = g1i.powZn(bp.getZr().newElementFromBytes(ID[i].getBytes()).getImmutable().mulZn(r[i])).mulZn(hi[i].powZn(r[i]));
            D0 = D0.mulZn(g1h[i]).getImmutable();
        }
        sk.setProperty("D0", D0.toString());


        storePropToFile(sk, skFile);
        storePropToFile(vPro, vectorFile);
        storePropToFile(random, randomFile);

        System.out.println("KeyGen phase completed.");
    }




    public static void Dec(String pairingFile, String paramsFile, String vectorFile, String skFile, String randomFile, String CTFile, int n, Double M, int l, int d, String[] ID) throws NoSuchAlgorithmException {
        Pairing bp = PairingFactory.getPairing(pairingFile);
        Properties params = loadPropFromFile(paramsFile);
        Properties CT = loadPropFromFile(CTFile);
        Properties sk = loadPropFromFile(skFile);
        Properties vector = loadPropFromFile(vectorFile);
        Element[] x = new Element[n];
        Element[] y = new Element[n];
        double sum = 0.0;
        for (int i = 0; i < n; i++) {
            String xStr = vector.getProperty("x" + i);

            x[i] = bp.getZr().newElementFromBytes(xStr.getBytes()).getImmutable();

            String yStr = vector.getProperty("y" + i);

            y[i] = bp.getZr().newElementFromBytes(yStr.getBytes()).getImmutable();

            sum += Double.valueOf(xStr) + Double.valueOf(yStr);
        }
        Element[] Ei = new Element[n+1];
        Element[] D = new Element[l+1];
        Element[] C = new Element[l+1];
        Element[] yi = new Element[n+1];
        Element A1 =PairingFactory.getPairing(pairingFile).getG1().newOneElement().getImmutable();
        Element A2 =PairingFactory.getPairing(pairingFile).getGT().newOneElement().getImmutable();

        for (int i = 1; i <= n; i++)
        {
            yi[i] = bp.getZr().newElementFromBytes(String.valueOf(y[i-1]).getBytes()).getImmutable();
            Ei[i] =  bp.getG1().newElementFromBytes(CT.getProperty("E"+i).getBytes()).getImmutable().powZn(yi[i]);
            A1 = A1.mul(Ei[i]).getImmutable();
        }

        for (int i = 1; i <= l; i++)
        {
            D[i] = bp.getG1().newElementFromBytes(sk.getProperty("Di"+i).getBytes(StandardCharsets.UTF_8));
            C[i] = bp.getG1().newElementFromBytes(CT.getProperty("Ck" + i).getBytes(StandardCharsets.UTF_8));
            A2 = A2.mul(bp.pairing(D[i],C[i]));
        }
        Element C0 = bp.getG1().newElementFromBytes(CT.getProperty("C0").getBytes(StandardCharsets.UTF_8));
        Element D0 = bp.getG1().newElementFromBytes(sk.getProperty("D0").getBytes(StandardCharsets.UTF_8));
        Element A3 = bp.pairing(C0,D0).getImmutable();

        Element xy = bp.getZr().newElementFromBytes(String.valueOf(sum).getBytes()).getImmutable();

        Element XY = A1.mulZn(A2).mulZn(A3.invert());
        Element g = bp.getG1().newElementFromBytes(params.getProperty("g").getBytes()).getImmutable();
        Element gi = bp.getG1().newElementFromBytes(params.getProperty("gi").getBytes()).getImmutable();

        Element EM = bp.pairing(g, gi).powZn(bp.getZr().newElementFromBytes(String.valueOf(M).getBytes()).getImmutable());
        if (XY.isEqual(EM)) {
            System.out.println("Decryption successful, message M is: " + M);
        } else {
            System.out.println("Decryption failed.");
        }
    }


    private static Element hash(String input, Pairing bp) throws NoSuchAlgorithmException {
        MessageDigest md = MessageDigest.getInstance("SHA-1");
        md.update(input.getBytes());
        byte[] digest = md.digest();
        BigInteger bi = new BigInteger(1, digest);
        return bp.getZr().newElement(bi);
    }

    private static Element computeKt(Pairing bp, Element t1) {
        return bp.getG1().newElementFromBytes(bp.getG1().newRandomElement().getImmutable().toBytes()).mulZn(t1);
    }

    private static Element computeU1(Pairing bp, Properties params, String[] ID, int d, Element t1) {
        Element u1 = bp.getG1().newElementFromBytes(params.getProperty("u" + 1).getBytes()).getImmutable();
        for (int i = 2; i <= d; i++) {
            u1 = u1.mulZn(bp.getG1().newElementFromBytes(params.getProperty("u" + i).getBytes()).getImmutable().powZn(bp.getG1().newElementFromBytes(ID[i - 1].getBytes()).getImmutable()));
        }
        return u1.mulZn(t1.invert());
    }

    private static Element computeKh1(Pairing bp, Properties sk, Element u1, String[] ID, int l, int d) {
        Element Kh = bp.getG1().newElementFromBytes(sk.getProperty("Kh").getBytes()).getImmutable();
        for (int i = l + 1; i <= d; i++) {
            Kh = Kh.mulZn(bp.getG1().newElementFromBytes(sk.getProperty("K" + i).getBytes()).getImmutable().powZn(bp.getZr().newElementFromBytes(ID[l].getBytes()).getImmutable().invert()));
        }
        return Kh.mulZn(u1);
    }

    public static void storePropToFile(Properties prop, String fileName) {
        try (FileOutputStream out = new FileOutputStream(fileName)) {
            prop.store(out, null);
        } catch (IOException e) {
            e.printStackTrace();
            out.println(fileName + " save failed!");
            System.exit(-1);
        }
    }

    public static Properties loadPropFromFile(String fileName) {
        Properties prop = new Properties();
        try (FileInputStream in = new FileInputStream(fileName)) {
            prop.load(in);
        } catch (IOException e) {
            e.printStackTrace();
            out.println(fileName + " load failed!");
            System.exit(-1);
        }
        return prop;
    }

    public static String getRandomString(int length) {
        String str = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
        Random random = new Random();
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < length; i++) {
            int number = random.nextInt(62);
            sb.append(str.charAt(number));
        }
        return sb.toString();
    }

    public static void main(String[] args) throws NoSuchAlgorithmException {
        String dir = "./storeFile/Belel/"; // Root path
        String pairingParametersFileName = dir + "a.properties";
        String ParameterFileName = dir + "params.properties";
        String mskFileName = dir + "msk.properties";
        String vectorFileName = dir + "vector.properties";
        String randomFileName = dir + "random.properties";
        String skFileName = dir + "sk.properties";
        String CTFileName = dir + "CT.properties";

        Random rand = new Random();
        int n = 10;
        int d = 10, l = 8;
        double[] x = new double[n];
        double[] y = new double[n];
        String[] ID = new String[d];
        for (int i = 0; i < d; i++) {
            ID[i] = getRandomString(10);
        }
        Double M = 0.0;
        for (int i = 0; i < n; i++) {
            x[i] = rand.nextInt(10);
            y[i] = rand.nextInt(10);
            M += x[i] * y[i];
        }
        System.out.println("M = " + M);

        long start = System.currentTimeMillis();
        setup(pairingParametersFileName, ParameterFileName, mskFileName, vectorFileName, n, d);
        long end = System.currentTimeMillis();
        System.out.println("Setup time: " + (end - start));

        start = System.currentTimeMillis();
        Encryption(pairingParametersFileName, ParameterFileName, vectorFileName, CTFileName, randomFileName, ID, n, x, d, l);
        end = System.currentTimeMillis();
        System.out.println("Encryption time: " + (end - start));

        start = System.currentTimeMillis();
        KGen(pairingParametersFileName, ParameterFileName, mskFileName, vectorFileName, skFileName, randomFileName, y, n, d, ID, l);
        end = System.currentTimeMillis();
        System.out.println("KeyGen time: " + (end - start));


        start = System.currentTimeMillis();
        Dec(pairingParametersFileName, ParameterFileName, vectorFileName, skFileName, randomFileName, CTFileName, n, M, l, d, ID);
        end = System.currentTimeMillis();
        System.out.println("Decrypt time: " + (end - start));

    }
}